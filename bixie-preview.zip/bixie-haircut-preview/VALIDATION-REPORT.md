# HTML preview validation

Tested on 6 October 2026 in the supplied cloud workspace. The delivery is an HTML design prototype, not a WordPress release.

## What was executed

| Check | Observed result |
| --- | --- |
| Real browser | Chromium through Python Playwright; local HTTP served the actual HTML, CSS, JavaScript and media |
| Responsive layout | 1440px desktop, 768px tablet, 390px and 320px phones: no horizontal page overflow |
| Reflow | 720 CSS pixels at scale 2, representing 200% desktop reflow: passed; this is not a browser UI zoom test |
| Browser errors/assets | No JavaScript page errors or failed referenced assets in the completed preview |
| Search and filters | Combined filters, reset, accurate counts and empty results passed; actual photo colours/fringes reviewed and corrected |
| Sorting | Curated order, A–Z and latest-in-this-edit passed |
| Favourites | Save/remove/clear, reload persistence and denied-storage session fallback passed |
| Comparison | Two/three-look shortlist, maximum three selections, dialog switching and mobile keyboard-scroll region passed |
| Image uniqueness | 25 distinct normal-page `img` sources plus one dedicated video poster; all 26 original source hashes differ |
| Detail and dialog controls | Original image nodes move into the requested view and restore on close/Escape; no simultaneous duplicated photos |
| Finder/navigation/notes | Preferences filter the actual eight-record edit; mobile keyboard navigation, Escape and focus restoration passed |
| Salon reference | Browser print invoked; actual A4 PDF rendered with selected photos, IDs, local preview URLs, notes and AI disclosure |
| Motion | Ribbon transforms change while visible; pause/offscreen/reduced-motion states work |
| Video | Included silent 12-second H264 MP4 decodes and plays; play/pause, offscreen handling, global pause and genuine missing-file feedback passed |
| Automated accessibility | Axe-core 4.14.0 WCAG 2 A/AA and 2.1 AA rules: zero reported violations on tested page, dialogs and mobile-menu states |
| Single-file copy | Served the actual self-contained HTML: all images, fonts, interactions and MP4 worked; only the HTML itself required an HTTP request |
| Delivered ZIPs | All archive integrity checks passed; extracted HTML package loaded all 25 image elements, search worked, and no asset/JavaScript errors occurred |
| Syntax | `node --check assets/app.js` passed |
| Asset preparation | WebP encodes preserve full source dimensions; signature image is displayed without cutting off its haircut outlines |
| Visual review | Final ribbon, texture, gallery, mature and guide layouts inspected, alongside hero, signature and motion sources |

The package contains eight interactive gallery records. Their texture/density labels are editorial concept metadata, not clinical measurements from a photograph. Colour and fringe filters follow the actual generated pictures. Copper legitimately returns an empty result in this eight-record gallery; separate original copper pictures appear elsewhere in the homepage.

## Scope and limits

- **Direct file opening: not verified.** The managed Chromium policy blocks `file://` navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. Local HTTP viewing was verified. Fonts, scripts and media are bundled; normal browser file policies and storage behavior can differ.
- Local Chromium checks do not establish Safari/Firefox/device coverage, a complete screen-reader audit, live Lighthouse scores or real-user Core Web Vitals. Automated accessibility still has manual-review items, including decorative/overlaid contrast. The film is silent, with no speech track.
- The video is a photographic motion study made from a dedicated original still, not recorded salon footage, a transformation or a reconstructed haircut rotation.
- The signature feature is one generated concept triptych. It is not three independent approved production media records.
- The 100-look/300-view library, full collection pages, substantive researched production guides, WordPress theme/plugin, editable Gutenberg implementation, imports and production SEO are **future work**, intentionally outside this HTML-only stage. Every major requirement remains in `docs/PRODUCTION-SCOPE.md`.
- No live US SERP audit, rankings, Search Console data, traffic, hosting/deployment, WordPress runtime/editor tests or production security checks were claimed. No promise to outrank every competitor is supported by these partial exports.
- A genuine owner contact address is still needed before launch. The preview does not invent an address or submit a form.

## Reproduce and inspect

- `tests/integration.py`: actual-page interaction, storage, failure handling, print and media checks; writes `tests/interaction-report.json`.
- `tests/qa-browser.py`: responsive geometry, assets, dialogs and axe checks; writes `tests/browser-observations.json`.
- `tests/qa-motion.py`: actual motion/video behavior; writes `tests/motion-observations.json`.
- `tests/prepare-assets.py`: format encoding and the dedicated still-image motion study. It needs original PNG sources, which are supplied separately from the lightweight preview.
- `tests/screenshots/`: actual browser captures and sample consultation PDF. Sample print URLs point at the tested local preview, not an assumed production domain.

The supplied-keyword review is reproducible through `python research/analyze_semrush.py --input-dir /path/to/csvs --output-dir /path/to/research` with the original uploaded CSVs. Those CSVs are user inputs, not runtime dependencies. Source dates and organic-versus-feature observations are preserved in the research outputs.

## Preview entry correction

The later compact delivery uses an 845,919-byte HTML file with 480px image derivatives, a 480x270 MP4 and seven subsetted font faces. Original source image hashes are unchanged. Document-only Chromium checks passed for loaded images/fonts, desktop/mobile styling, search, saving, comparison and video, with zero external requests or page errors. Reports are `tests/compact-build-report.json` and `tests/compact-qa-report.json`. The actual chat Open/Download controls remain unverified.

The user's embedded viewer displayed the original default `index.html` without its external stylesheet. The screenshot showed default links and incorrectly sized/filled SVGs. The default entry now embeds CSS, JavaScript, fonts, 25 image elements and its dedicated motion poster/video. SVGs also have explicit safe sizes, fill and stroke attributes. Editable markup is preserved as `source.html`; the builder reads that source and regenerates the self-contained default entry.

`tests/preview-isolation.py` passed with only the HTML document available and every sibling request configured to return 404: all images decoded, local fonts and computed styles loaded, icons kept their correct size, search/saved looks/mobile navigation/video worked, and no external asset request was made. The complete interaction suite also passed against the corrected default entry. The actual chat viewer is not accessible from the test tools, so these checks establish document-only rendering in Chromium rather than claiming a confirmed result inside that viewer.
