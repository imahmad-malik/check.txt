#!/usr/bin/env python3
"""Reproduce a conservative Bixie-specific review of the seven supplied exports.

No web/SERP fetches. Preserve source snapshot differences and SERP feature flags.
"""
from pathlib import Path
from collections import defaultdict, Counter
import csv
import json
import re
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-dir', type=Path, default=Path('/workspace/attachments'), help='Folder containing the seven supplied CSVs; searched recursively')
parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent, help='Research output folder')
args = parser.parse_args()
ROOT = args.input_dir
OUT = args.output_dir
OUT.mkdir(parents=True, exist_ok=True)

DIRECT = re.compile(r'\bbixie\b|\bbixies\b|pixie.{0,10}bob|bob.{0,10}pixie', re.I)
CONTEXT = re.compile(r'\b(?:pixie|bob|bangs|fringe|fine hair|thin hair|thick hair|coarse hair|short hair|short hairstyles|short haircuts|round face|curl types|curl pattern)\b', re.I)
SUPPORT = re.compile(r'fine.{0,10}(?:vs|versus|and|or).{0,10}(?:thin|thick|coarse)|thin.{0,10}(?:vs|versus|and|or).{0,10}(?:fine|thick)|coarse.{0,10}(?:vs|versus|and|or).{0,10}fine|how to style short hair|growing out.{0,10}(?:pixie|short)|grow out.{0,10}(?:pixie|short)|styling short (?:hair|pixie)', re.I)

def norm(v):
    return re.sub(r'\s+', ' ', v.strip().lower())

def source_name(p):
    return 'keyword_magic' if p.name.startswith('keywordmagic_') else p.name.split('_positions_')[0]

def classify(k):
    if DIRECT.search(k):
        if re.search(r'florence pugh|zendaya', k):
            return 'Excluded celebrity-specific intent', 'Exclude from fictional model library', '/guides/bixie-vs-pixie-vs-bob/', 'Do not fabricate celebrity photos or imply an endorsement.'
        if k == 'bobs and pixie cuts':
            return 'Adjacent broad comparison', 'Optional comparative context', '/guides/bixie-vs-pixie-vs-bob/', 'A broad bob-and-pixie query is not exclusively bixie intent.'
        if 'boy bob' in k:
            return 'Primary direct comparison', 'Comparison guide', '/guides/bixie-vs-pixie-vs-bob/', 'Explain boy bob, bixie, pixie and bob differences in one substantive guide.'
        if 'wolf' in k or 'shixie' in k:
            return 'Primary direct comparison', 'Shaggy hybrid explanation', '/guides/bixie-vs-shixie-vs-wolf-cut/', 'Explain overlapping names without treating structurally different cuts as synonyms.'
        if re.search(r'^what|^whats', k):
            return 'Primary direct definition', 'Definition guide', '/guides/what-is-a-bixie-haircut/', 'One canonical definition page; no spelling-variant pages.'
        if '2025' in k:
            return 'Historical direct intent', 'Historical context only', '/looks/', 'Do not present an old year as a fresh collection; avoid annual doorway pages.'
        if '2026' in k or 'trend' in k:
            return 'Primary direct seasonal intent', 'Current curated edit', '/looks/', 'Use a genuinely maintained latest edit with truthful dates; avoid duplicated year pages.'
        if 'fine hair' in k:
            return 'Primary direct collection', 'Fine hair', '/collections/fine-hair/', 'Fine strand diameter is distinct from low hair density.'
        if 'thin hair' in k:
            return 'Primary direct collection', 'Thin hair', '/collections/thin-hair/', 'Use credible lower-density references; do not promise regrowth or extra density.'
        if 'over 50' in k:
            return 'Primary direct collection', 'Over 50', '/collections/over-50/', 'Dignified age-inclusive references; no guaranteed younger-looking claims.'
        if 'over 60' in k:
            return 'Primary direct collection', 'Over 60', '/collections/over-60/', 'Age is a browsing context, not a haircut suitability rule.'
        if 'curly' in k:
            return 'Primary direct collection', 'Curly hair', '/collections/curly-hair/', 'Show credible curl patterns and the haircut shape.'
        if 'wavy' in k:
            return 'Primary direct collection', 'Wavy hair', '/collections/wavy-hair/', 'Show natural wave and relevant styling context.'
        if 'bangs' in k:
            return 'Primary direct collection', 'Bangs and fringe', '/collections/bangs/', 'Keep curtain, wispy, full and side-swept fringe as browsable facets until distinct galleries exist.'
        if 'round face' in k:
            return 'Primary direct collection', 'Round-face references', '/collections/round-face/', 'Reference category only; do not imply universal suitability.'
        if '90' in k:
            return 'Primary direct collection', '90s-inspired', '/collections/90s-inspired/', 'Combine apostrophe and word-order synonyms.'
        if 'low' in k and 'maintenance' in k:
            return 'Primary direct collection', 'Easy styling', '/collections/easy-styling/', 'Explain maintenance tradeoffs; texture and desired finish determine effort.'
        if 'undercut' in k:
            return 'Primary direct collection', 'Undercut', '/collections/undercut/', 'Publish only clearly documented bixie hybrids with undercut details.'
        if 'long' in k:
            return 'Primary direct collection', 'Long bixie', '/collections/long/', 'Long pixie-bob equivalents belong here only when the haircut is a real hybrid.'
        if 'layered' in k:
            return 'Primary direct collection', 'Layered', '/collections/layered/', 'Show crown, face-framing and nape structure across angles.'
        if 'images' in k:
            return 'Primary direct gallery', 'Gallery archive', '/looks/', 'Use indexable image elements, meaningful alt text and complete look references.'
        if 'pixie' in k and 'bob' in k:
            return 'Primary equivalent-name intent', 'Bixie archive and definition', '/looks/', 'Name equivalence is useful; do not relabel ordinary bobs or pixies.'
        return 'Primary direct head/synonym', 'Homepage and main archive', '/', 'Consolidate spelling, plural and short-name variants; no duplicate synonym pages.'
    if SUPPORT.search(k):
        if re.search(r'grow|growing', k):
            return 'Selected supporting intent', 'Growing out a bixie', '/guides/growing-out-a-bixie/', 'Use pixie grow-out comparisons within a bixie-specific guide; no rank claim for the broad query.'
        if re.search(r'fine|thin|coarse', k):
            return 'Selected supporting intent', 'Texture and density guide', '/guides/fine-vs-thin-hair/', 'Explain strand thickness and density; broader fine/coarse comparison is supporting context.'
        return 'Selected supporting intent', 'Styling guide', '/guides/styling-a-bixie/', 'Answer the relevant short-hair task while retaining bixie focus.'
    if CONTEXT.search(k):
        return 'Context only, broader than bixie', 'Selective reference only', '', 'Not a dedicated launch target without clear bixie intent and differentiated coverage.'
    return 'Outside specialist bixie scope', 'Excluded from launch targeting', '', 'Unrelated hairstyles, brands, products, entertainment and other broad categories are not site targets.'

files = sorted(ROOT.rglob('*.csv'), key=lambda p: p.name)
observations = defaultdict(list)
file_summary = []
exact_rows = set()
raw_total = 0
full_row_dupes = 0
logical_records = {}

for p in files:
    with p.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    raw_total += len(rows)
    source = source_name(p)
    file_summary.append({
        'filename': p.name, 'source': source, 'rows': len(rows),
        'unique_keywords': len({norm(r['Keyword']) for r in rows}),
        'direct_match_rows': sum(bool(DIRECT.search(r['Keyword'])) for r in rows),
        'direct_match_unique_keywords': len({norm(r['Keyword']) for r in rows if DIRECT.search(r['Keyword'])}),
        'earliest_snapshot_or_crawl': min(r.get('Snapshot Date') or r.get('Crawled Time') or '' for r in rows),
        'latest_snapshot_or_crawl': max(r.get('Snapshot Date') or r.get('Crawled Time') or '' for r in rows),
    })
    for row in rows:
        k = norm(row['Keyword'])
        evidence = {'source': source, 'source_file': p.name, **row}
        observations[k].append(evidence)
        exact = (source, tuple(sorted(row.items())))
        if exact in exact_rows:
            full_row_dupes += 1
        exact_rows.add(exact)
        # The two Laura exports overlap and can vary in other report-derived fields.
        # Preserve distinct URLs, SERP slots, feature observations and crawl dates.
        identity = (source, k, row.get('URL', ''), row.get('Position', ''),
                    row.get('positionIsSERPFeature', ''), row.get('positionOnSERP', ''),
                    row.get('positionSERPFeatures', ''), row.get('serpFeatureIndex', ''),
                    row.get('Crawled Time', ''), row.get('Snapshot Date', ''),
                    row.get('Volume', ''), row.get('KD %', row.get('Difficulty', '')))
        if identity not in logical_records:
            logical_records[identity] = {'keyword': k, 'source': source, 'source_files': set(),
                'volume': row.get('Volume', ''), 'difficulty': row.get('KD %', row.get('Difficulty', '')),
                'position': row.get('Position', ''), 'is_serp_feature': row.get('positionIsSERPFeature', ''),
                'position_on_serp': row.get('positionOnSERP', ''), 'serp_feature_codes': row.get('positionSERPFeatures', ''),
                'url': row.get('URL', ''), 'snapshot_or_crawl': row.get('Snapshot Date', row.get('Crawled Time', ''))}
        logical_records[identity]['source_files'].add(p.name)

def write_csv(name, rows, fields):
    with (OUT / name).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

write_csv('export_inventory.csv', file_summary, list(file_summary[0]))

obs_rows = []
for x in logical_records.values():
    if not DIRECT.search(x['keyword']):
        continue
    row = dict(x)
    row['source_files'] = '; '.join(sorted(row['source_files']))
    obs_rows.append(row)
write_csv('direct_keyword_observations.csv', sorted(obs_rows, key=lambda r:(r['keyword'],r['source'],r['is_serp_feature'],r['position_on_serp'])), list(obs_rows[0]))

def values(evidence, field):
    return '; '.join(sorted({e.get(field, '') for e in evidence if e.get(field, '')}, key=lambda x: float(x)))

def best_organic(evidence):
    ranks = defaultdict(list)
    for e in evidence:
        if e.get('positionIsSERPFeature') == 'false' and e.get('Position', '').isdigit():
            ranks[e['source']].append(int(e['Position']))
    return '; '.join(f'{s}: {min(v)}' for s, v in sorted(ranks.items()))

review = []
for keyword, evidence in sorted(observations.items()):
    classification, cluster, route, note = classify(keyword)
    km = [e for e in evidence if e['source'] == 'keyword_magic']
    positions = [e for e in evidence if e['source'] != 'keyword_magic']
    review.append({
        'keyword': keyword, 'classification': classification, 'coverage_cluster': cluster,
        'suggested_route': route, 'keyword_magic_volume': values(km, 'Volume'),
        'keyword_magic_difficulty': values(km, 'Difficulty'),
        'keyword_magic_snapshot': '; '.join(sorted({e.get('Snapshot Date', '') for e in km})),
        'positions_export_volume': values(positions, 'Volume'),
        'positions_export_kd': values(positions, 'KD %'),
        'best_exported_organic_position_by_competitor': best_organic(positions),
        'sources': '; '.join(sorted({e['source'] for e in evidence})),
        'source_files': '; '.join(sorted({e['source_file'] for e in evidence})),
        'notes': note,
    })
write_csv('all_keywords_review.csv', review, list(review[0]))
direct = [r for r in review if DIRECT.search(r['keyword'])]
write_csv('bixie_keyword_coverage.csv', direct, list(review[0]))
support = [r for r in review if r['classification'] == 'Selected supporting intent']
write_csv('supporting_keyword_candidates.csv', support, list(review[0]))

laura_files = [p for p in files if p.name.startswith('laurakcollins')]
laura_rows = [list(csv.DictReader(p.open(encoding='utf-8-sig', newline=''))) for p in laura_files]
laura_exact_overlap = len({tuple(sorted(r.items())) for r in laura_rows[0]} & {tuple(sorted(r.items())) for r in laura_rows[1]})
summary = {
    'export_files': len(files), 'raw_rows': raw_total, 'unique_normalized_keywords': len(observations),
    'exact_duplicate_rows_removed_across_same_source': full_row_dupes,
    'rows_after_exact_dedup': len(exact_rows),
    'logical_observations_after_source_url_slot_date_metric_dedup': len(logical_records),
    'laura_exact_overlap_rows': laura_exact_overlap,
    'laura_unique_keyword_union': len({norm(r['Keyword']) for rr in laura_rows for r in rr}),
    'direct_match_unique_keywords': len(direct),
    'direct_match_raw_rows': sum(x['direct_match_rows'] for x in file_summary),
    'bixie_word_unique_keywords': sum(bool(re.search(r'\bbixie\b|\bbixies\b', r['keyword'])) for r in direct),
    'direct_keywords_excluding_celebrity_and_broad_bobs_and_pixie': sum(not r['classification'].startswith(('Excluded', 'Adjacent broad')) for r in direct),
    'selected_supporting_unique_keywords': len(support),
    'classification_counts': dict(Counter(r['classification'] for r in review)),
    'no_live_google_serp_audit_performed': True,
    'snapshot_warning': 'Filename date is not the data snapshot; Keyword Magic Snapshot Date is 20260801.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
