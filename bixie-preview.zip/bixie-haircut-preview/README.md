# Bixie Haircut — HTML design preview

An extra-long, gallery-first homepage for reviewing the visual direction before commissioning the WordPress theme. This delivery follows the latest instruction: **HTML preview only**. The older master prompt supplies the future production requirements.

## Open the preview

For the quickest review, open `index.html` inside the extracted HTML package. It is the compact, single-file homepage (826 KiB) with photographs, fonts, styles, script and motion study embedded. Images and video have lower resolution in this copy to reduce file size. Open `source.html` with its bundled sibling assets for full quality. The separate standalone full quality copy is `Bixie-Haircut-Preview.html`, available outside the ZIP.

Edit `source.html`, `assets/style.css` and `assets/app.js`, then run `python3 tests/package-release.py` to regenerate the full quality self-contained entry and ZIPs. The builder preserves an existing compact entry in the ZIP. After editing sources, rebuild the compact copy too to update that entry; `tests/compactbuilder.py` needs original PNGs from the separate originals ZIP, ffmpeg and Python fonttools with Brotli. `tests/prepare-assets.py` also needs the source PNGs. The HTML-only package can be repackaged without source PNGs; the builder then skips the originals archive. The compact builder does not automatically follow edits to the full quality source.

1. Extract the complete preview ZIP into a folder.
2. Open `index.html` in a current browser. The default `index.html` embeds its runtime assets, so it also works when a viewer cannot resolve sibling files. Keep the other files for editing and rebuilding.
3. Scroll through the full homepage; try filters, saved looks, comparison, the finder, image zoom and the salon print sheet.

All runtime JavaScript, CSS, photographs, fonts and the motion-study MP4 are bundled locally. No package installation, build command, account or external runtime dependency is needed. Internet access is unnecessary to view the extracted preview.

The actual chat file viewer's Open/Download controls cannot be checked with the available tools. Smaller files and placement within the selected checkout are delivery attempts; they do not confirm that interface's access works.

For consistent browser storage during review, optionally open a terminal in the extracted folder and run:

```bash
python3 -m http.server 8000
```

Then open the server in that same browser using its local address. This is a local viewing method, not a public preview or deployment. Direct file opening could not be verified in the managed test browser because its policy blocks file URLs. The local HTTP workflow was verified. File-based browser storage behavior varies; saved looks persist only when the browser permits storage. When storage is unavailable, the shortlist lasts for that visit.

## What to review

- Editorial typography, asymmetrical portraits, a moving photographic ribbon, a dark three-angle feature and a dedicated motion section.
- Eight functional gallery look records with search, combined filters, sorting, reset and an empty state.
- Saved looks, comparison of two or three selections, image detail/zoom, a preference finder and browser print/save-as-PDF.
- Six core guide previews plus additional coverage notes, trust-page previews, responsive navigation and the future coverage direction.

Use the ribbon pause control and the video play control to assess motion. The film is a **12-second slow motion study of an original still image**, not recorded salon footage or a rotating reconstruction. Browser print/save-as-PDF is a working browser action; no separate PDF-generation service is included.

## Photographs and counts

The runtime asset map selects **26 original AI-created artworks**, optimized as WebP. Each photograph appears once in the normal homepage composition. Opening a look, saved view, comparison or print sheet temporarily moves its original image node into that view and restores it afterward; it does not duplicate the photograph across simultaneous homepage sections.

The gallery contains **8 looks with one portrait each**. The signature feature is **one concept triptych artwork**, not three separately approved production view records. This is not a delivered 100-look / 300-angle launch library. Source PNG originals are kept separately from the lightweight preview ZIP; do not count WebP renditions as additional original looks or photographs. Consult `assets/image-manifest.json` and `assets/asset-map.json` for filenames, generation information and asset status.

## Keyword coverage and limits

The seven supplied Semrush exports contain **13,907 rows**. The review identifies **48 relevant direct/equivalent candidates** and **30 supporting candidates**. Those are partial snapshots with overlapping data, not a complete SEO audit or a promise of first place. The historical 2025 term remains documented rather than becoming a new 2026 page. Source dates, measured terms, exclusions and the future page map are in [research/coverage-plan.md](research/coverage-plan.md).

Read [docs/DESIGN-NOTES.md](docs/DESIGN-NOTES.md) for design decisions and [docs/PRODUCTION-SCOPE.md](docs/PRODUCTION-SCOPE.md) for every major requirement still needed in the future WordPress package. Executed checks and remaining verification limits belong in `VALIDATION-REPORT.md`; this README does not certify unexecuted tests.

This preview does not include an installable WordPress theme/plugin, a verified WordPress editor, production imports, complete collection pages, live SEO results or real-user Core Web Vitals. Review the design first; the full production checklist remains explicit.
