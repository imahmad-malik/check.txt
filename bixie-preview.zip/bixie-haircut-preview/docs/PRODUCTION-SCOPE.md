# Future production scope — Bixie Haircut

## Current delivery and controlling instruction

The current authorized deliverable is an **HTML design preview**, based on the latest request to review the homepage before commissioning a theme. The older master prompt remains the reference for the eventual complete WordPress package. A design preview is not an installable WordPress theme or plugin.

The current package demonstrates a long homepage, 26 original display artworks, eight one-portrait gallery records, a single three-angle concept triptych, a 12-second still-image motion study, visitor-tool interactions and concise guide/trust previews. It includes analysis of seven Semrush exports. No 100-look / 300-approved-angle library, production WordPress installation, editor round trip, runtime import flow, live ranking or real-user performance result is established by this delivery.

Every checklist item below is a **future production acceptance requirement**. It is not marked complete by a visual preview. The current `VALIDATION-REPORT.md` covers only executed checks within this delivery's scope.

## Release packages and architecture

- [ ] Deliver an actual installable `bixie-haircut-theme.zip`, implemented as a custom WordPress block theme.
- [ ] Deliver an actual installable `bixie-haircut-core.zip` companion plugin with durable, prefixed content definitions and gallery functionality.
- [ ] Keep presentation in the theme and look types, taxonomy, registered metadata, dynamic functionality, setup/import and diagnostics in the plugin.
- [ ] Include built runtime assets; installation on normal WordPress hosting must not require Node/npm, a paid builder or paid fields plugin.
- [ ] Declare WordPress/PHP versions and extensions that were actually tested. Degrade gracefully when the companion plugin is inactive.
- [ ] Use WordPress APIs for environment-aware media URLs, site URLs, routes and settings. Avoid hard-coded assumed production/local URLs.
- [ ] Include maintainable source, build instructions and documented dependencies/licenses.

## Content model and record integrity

- [ ] Register a prefixed Look post type, validated editable metadata and meaningful taxonomies for texture, density, length, fringe, shape/finish, age reference, color and appropriate editorial facets.
- [ ] Store media as WordPress attachments and relationships through supported fields/taxonomies. Distinguish look counts from image-view counts and rendition counts.
- [ ] Assign stable look IDs for favourites, comparison and resumable import; keep them stable after title/slug changes.
- [ ] Restrict published look records to complete, reviewed views and truthful attributes. Do not fill missing angles by relabeling a duplicate portrait.
- [ ] Support the roadmap of 180 looks/540 views and later 250–300 looks/750–900 views without counting those planned assets as delivered.
- [ ] Keep public queries bounded and limited to published data. Avoid sending all full-resolution media in the initial page response.

## Original image library and video

- [ ] Complete the earlier 12-look/36-view art-direction pilot with coherent individual front, side and back sources; review identity and haircut consistency before scaling.
- [ ] Deliver **100 distinct launch looks and 300 approved individual view assets**, excluding crops, renditions, retakes and rejected work.
- [ ] Review visible crown, face frame, fringe, side length, color, parting, density and nape across each three-view set.
- [ ] Use fictional adults, varied skin tones and ages, believable fine/wavy/curly/coily textures and dignified mature/grey imagery.
- [ ] Preserve haircut information through responsive crops; inspect artifacts and avoid unrealistic skin, hands, ears, strand patterns, text/logos and unsupported hairstyle labels.
- [ ] Provide a manifest with stable look ID, title, attributes, angle filenames, captions, actual image-specific alt text, dimensions/formats, prompts, generation/review/approval status and completeness.
- [ ] Supply optimized launch media and separately organized high-resolution sources. Record actual source resolution and accurately label any optional upscaling.
- [ ] Use each photograph once in the curated homepage composition. Share canonical records across relevant production collections where appropriate.
- [ ] Keep the AI-concept disclosure visible and avoid celebrity, customer transformation or salon-result claims.
- [ ] Decide the approved production video scope. The preview's still-image MP4 does not satisfy a request for recorded salon footage or actual rotating views. Any future video must have its source, rights, representation and delivery tested.

## Homepage and owner editing

- [ ] Agree the final section order/copy after reviewing this HTML design. The latest long premium-design direction develops the older mockup instructions; the absent mockup has not been silently treated as inspected.
- [ ] Build the masthead, editorial hero, moving photographic ribbon(s), functional search/filter controls, texture tiles, main collection, signature three-angle feature, mature/grey collections, guides and complete footer.
- [ ] Make all copy, images, buttons, menus, selected looks/collections, section order and visibility editable through core blocks and documented custom blocks where needed.
- [ ] Expose theme palette, typography and spacing through `theme.json`. Include licensed local fonts and a responsive visual system.
- [ ] Provide real editor previews and stable block serialization; no invalid/broken Gutenberg blocks.
- [ ] Let the owner replace individual views from the Media Library; edit metadata, captions and notes; select featured looks and tiles; preview/publish/draft records; and revise content safely.
- [ ] Provide clear Looks, Collections, Homepage and necessary Settings screens. Permit section reorder/hide/show/duplicate, configurable motion enablement/speed and scoped reset behavior without opening code.
- [ ] Verify editing text, photographs, blocks and saved revisions produces the correct front-end result without overwriting unrelated content.

## Routes, browsing and visitor tools

| Production destination | Required behavior |
|---|---|
| `/` | Editable gallery-first home with real links and truthful counts |
| `/looks/` | Searchable/filterable server-rendered archive with linked pagination |
| `/looks/{look-slug}/` | Complete three-view detail, captions, attributes, notes and related looks |
| `/collections/` | Useful collection directory without empty launch destinations |
| `/collections/{collection-slug}/` | Differentiated copy and sufficiently populated relevant looks |
| `/guides/`, `/guides/{guide-slug}/` | Publicly accessible substantive articles and guide index |
| `/saved/` | Browser-local stable-ID shortlist with remove/clear and empty state |
| `/compare/` | Two or three selected looks, corresponding angles and concise attributes |
| Print view | Three angles, look title/URL, useful notes and disclosure; browser print/save-as-PDF |
| Search/404/empty states | Clear recovery and navigation with accurate indexability |

- [ ] Implement real search, combined filters, reset, result counts, curated/latest sorting and useful pagination over published records.
- [ ] Keep crawlable linked pagination even when enhanced loading is available; do not hide all indexable content behind scroll/button actions.
- [ ] Provide accessible zoom/lightbox, angle controls and related looks chosen by actual tags.
- [ ] Support favourites persistence, graceful storage failure, clear/remove controls and truthful privacy copy.
- [ ] Verify compare and print on mobile and with the keyboard. A direct PDF download label requires a real separately tested generator.
- [ ] Implement the preference finder as a browsing aid, without guaranteed suitability or facial-analysis claims.
- [ ] Configure and test rewrite rules without collisions and support sensible no-JavaScript browsing.

## Collections, guides and essential pages

- [ ] Publish approximately **20 useful, distinct collection landing pages**, adjusted to verified intent and complete available content. A planned empty collection is not a launch page.
- [ ] Use the supplied research map for direct/equivalent subjects: bixie/pixie-bob, fine strands, thin density, curly/wavy, long/layered, bangs, easy styling, over 50/60, 90s, round-face references and relevant comparisons. Merge synonyms with the same intent.
- [ ] Review editorial breadth such as short/classic, straight/thick, choppy/feathered, specific fringes, over 40/natural grey and color/face-shape facets without inventing demand. Use filters when an indexable collection is not sufficiently distinct.
- [ ] Write six substantive original guides: definition/comparison; stylist discussion; styling; fine versus thin; three-angle references; grow-out. A differentiated shixie/wolf-cut comparison is optional when useful.
- [ ] Research technical haircut advice through appropriate primary/authoritative references; do not claim personal salon experience or credentials. Use natural relevant internal links and no filler word-count targets.
- [ ] Deliver Home, Collections, Looks, Guides, About, Contact, Image Policy, Privacy and Disclaimer, plus search/404/empty templates.
- [ ] Configure a genuine owner contact email. An absent address is a launch dependency; do not invent an address or include a nonworking form.
- [ ] Make privacy and disclaimer text match actual browser storage, cookies, hosting, analytics and forms. Do not auto-install analytics/advertising or fabricate social accounts/newsletter services.
- [ ] Keep gallery content visually dominant and guides public but secondary. Use one H1 per page and coherent H2/H3 editorial hierarchy.

## SEO, research and indexability

- [ ] Perform a current US search/image competitor review where accessible. The supplied seven partial CSVs are an initial evidence source, not a live top-five audit or complete competitor inventory.
- [ ] Keep export estimates, organic positions, feature slots, source dates and hypotheses distinct. Do not sum synonymous demand or invent unavailable volume, KD, traffic/backlinks or rankings.
- [ ] Maintain a canonical subject/page map and an explicit indexability matrix. Meaningful collections/look/guide pages can be eligible; internal search, saved/compare and unwanted faceted combinations must not create unlimited indexed pages.
- [ ] Render real accessible `img`/`picture` sources, image-specific alt text, meaningful content and stable crawlable links on the server.
- [ ] Give indexable pages useful unique titles/descriptions and proper canonical/robots output. Maintain sensible self-canonicals for paginated archives rather than pointing every page to page one.
- [ ] Implement truthful applicable WebSite, CollectionPage, ItemList, ImageObject, BreadcrumbList and Article structured data; no invented ratings/reviews or nonexistent haircut rich result.
- [ ] Define output ownership with active Yoast/Rank Math to avoid duplicate titles, canonicals, robots, schema and sitemaps. Verify actual rendered output.
- [ ] Verify XML and image sitemap URLs and avoid automatic search-indexed attachment pages for every angle.
- [ ] Keep important public content out of accidental noindex/draft/login states. Retain preview noindex until production is ready.
- [ ] Document Search Console property setup and sitemap submission. Do not promise guaranteed indexing or misuse obsolete ping/Indexing API flows.
- [ ] Measure post-launch results. Original images, coverage, animation, schema and exact-match branding do not guarantee ranking above every competitor.

## Performance, motion and accessibility

- [ ] Generate WordPress responsive image sizes and correct `srcset`/`sizes`, with WebP/AVIF where supported and compatible delivery.
- [ ] Reserve image geometry, prioritize the primary hero, lazy-load appropriate lower media and avoid redundant large downloads.
- [ ] Keep JavaScript/query work lean, paginate data and invalidate any cached results after content changes.
- [ ] Animate suitable transform/opacity properties, pause offscreen movement, respect reduced motion, provide pause/resume and avoid scroll-jacking/flashing/autoplay background film.
- [ ] Verify keyboard navigation, semantic names/headings, visible focus, contrast, tap targets, mobile navigation, dialog focus trapping/restoration, Escape closing and browser zoom.
- [ ] Document actual measured lab conditions/results. Real-user targets remain LCP ≤2.5s, INP ≤200ms and CLS ≤0.1 at the 75th percentile; field verification requires real post-launch data.
- [ ] Distinguish lab tests from live lab/field metrics and do not substitute TBT for measured INP or fabricate PageSpeed scores.

## Safe setup, imports and security

- [ ] Provide an owner-initiated capability-protected setup/import flow for pages, navigation, manifests and content.
- [ ] Make import idempotent and resumable with tracked small batches; never upload hundreds of assets during one activation request.
- [ ] Avoid duplicate posts/media on rerun; preserve owner edits and unrelated existing content/settings/plugins.
- [ ] Distinguish project-created records from pre-existing site content, and prevent incomplete look publication.
- [ ] Report missing images/pages, incomplete sets, invalid settings and import progress through helpful diagnostics and scoped recovery.
- [ ] Apply capability checks, nonces where needed, validated input, escaped output, prepared queries and proper REST permissions.
- [ ] Bound allowed public query parameters and preserve published-data restrictions.
- [ ] Keep secrets/private data out of code, logs and manifests. Include no hidden admin access, arbitrary file writers, remote executable code or obfuscation.
- [ ] Verify repeated import, interruption/resume, owner-edit preservation and scoped section resets.

## Verification and documentation before release

- [ ] Verify clean theme/plugin install, activation/deactivation and all required routes on the actual declared WordPress/PHP environment.
- [ ] Check PHP syntax, relevant WordPress debug logs, browser console errors, missing assets and broken links.
- [ ] Verify the editor-to-front-end round trip, image replacement, revisions and block validity.
- [ ] Execute functional tests for combined filters/search/reset/sort/pagination/empty results; favourites; compare; print; lightbox; finder; mobile menu and ribbon pause/resume.
- [ ] Validate exactly 100 complete launch looks and 300 approved source views without inflating counts with renditions or triptych panels.
- [ ] Verify SEO-plugin coexistence, metadata, canonical/robots/schema and sitemap behavior.
- [ ] Capture responsive screenshots of homepage and representative archive/detail/tool/editor flows, and report accessibility/lab findings with actual evidence.
- [ ] Deliver `OWNER-GUIDE.md` for installation, editing, media, motion controls, backup/export, updates and recovery.
- [ ] Deliver `VALIDATION-REPORT.md` identifying executed checks, environment, results, screenshots, defects and unavailable checks.
- [ ] Deliver `LAUNCH-CHECKLIST.md` for domain/hosting, genuine owner contact/policy information, supported WordPress configuration, SSL, caches and Search Console.
- [ ] Prepare tested staging packages and reviewable files. Deploy only when site access and deployment authorization are available; domain/hosting absence should not stop independent implementation.

The future production package is complete only when its installable theme/plugin, functionality, launch content and approved image library are actually delivered and tested. Any missing code, assets, owner information or unavailable verification must remain explicit.
