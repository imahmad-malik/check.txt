# Design notes — Bixie Haircut HTML preview

## Brief and review purpose

The latest request asks for a premium, extra-long HTML homepage to inspect before building a theme. It also asks for broader keyword coverage, distinct photographs throughout the homepage, moving imagery and a cinematic flow. The earlier master prompt defines the brand and future WordPress package. Its instruction to deliver WordPress ZIPs is superseded for this review by the latest HTML-only request.

No existing homepage HTML or mockup was available among the supplied attachments. The written brief and the supplied keyword exports informed this design; a missing visual reference has not been claimed as inspected or reproduced.

## Visual system

| Element | Direction |
|---|---|
| Background | Warm ivory `#F6F2EC`; soft stone photograph surrounds |
| Body and dark feature panel | Inky charcoal, approximately `#252525` |
| Accent | Muted copper `#A86A4A`, used sparingly |
| Display type | Instrument Serif, with restrained italic emphasis |
| Body and controls | DM Sans, readable text and clearly labeled controls |
| Symbol support | Noto Sans Symbols 2 |
| Font delivery | Local WOFF2 files; license texts included in `assets/fonts/` |
| Geometry | Thin rules, restrained corners, limited shadows and generous purposeful spacing |
| Photography | Neutral backgrounds, believable texture and crops that preserve haircut information |

The wordmark, numbered editorial markers, alternating image scales and contrasting dark panel create a consistent identity across a long page. Serif headlines carry the editorial voice; the sans-serif controls keep browsing legible. The design avoids fabricated prestige claims, customer testimonials, decorative statistics and a dominant blog layout.

The homepage uses “Short cut. Long story.” as its display headline, supported by the Bixie Haircut eyebrow and gallery call to action. This is a reviewable design choice. Future production can edit that copy through the block editor without changing the visual system.

## Page rhythm

1. Compact edition bar, wordmark, navigation, search and saved-look tools.
2. Asymmetrical editorial hero with two distinct portraits.
3. A staggered moving photographic ribbon, followed by a quiet editorial line.
4. Four texture collection tiles and a short definition interlude.
5. Search, filters and eight curated gallery cards.
6. Full-width dark panel showing a single three-angle concept artwork.
7. User-controlled photographic motion study.
8. Mature and natural-grey visual directions.
9. A preference finder that routes visitors into the existing gallery.
10. Secondary guide previews and further reading links.
11. Collection-direction index, closing call to action and transparent footer.

The latest premium-design request allowed the earlier section order and copy to be developed. The prototype has a single staggered ribbon rather than the earlier brief's two complete ribbon rows. Search is attached to the working gallery rather than positioned before the texture tiles. These choices should be reviewed as part of the HTML design, not assumed to be approved production specifications.

## Image direction and uniqueness

The 26-artwork allocation is two hero portraits, four ribbon portraits, four texture portraits, eight gallery portraits, one signature triptych, one motion-study source, three mature/grey portraits and three guide illustrations. This allocation describes display artwork, not 26 published, complete hairstyle records.

Models are fictional adults; the images are AI-created concepts. They are not salon results, celebrity photographs or customer evidence. Descriptions should match the actual haircut and visible view. The final production library requires individual front, side and back assets and consistency review for each look. A crop or recolor does not become a new haircut structure merely because it is a different file.

Each selected artwork occupies one homepage position. Ribbon motion must not clone the photos into repeated visible tiles. Gallery modal tools temporarily move the original image node rather than make another copy. The dedicated motion source appears as the film poster and supplies the film; those are the same study, not an additional collection portrait.

For the future production site, a single canonical look can belong to multiple useful collections through stable records and taxonomy relationships. That normal browsing relationship is compatible with the requested unique homepage composition. Reusing the same canonical look across collections does not establish an inherent SEO penalty.

Keep the source PNG originals outside the lightweight preview package. `assets/asset-map.json` connects runtime names to original asset names. The separate image manifest should retain real source dimensions, prompts, source paths, generation status and review status. Do not describe generated dimensions as native 8K unless the source supports that claim.

## Motion and interaction

The design uses slow ribbon movement and restrained reveal/hover transitions. A visible pause control gives the reader ownership of continuous motion. Reduced-motion preferences should suppress decorative movement while leaving the complete content available. Offscreen motion should stop; focus and reading must not depend on animation.

The MP4 is a 12-second slow photographic motion study made from a still source. It is user controlled, muted and labeled as a motion study. It is not salon footage and does not demonstrate real changes in the haircut. Original recorded or appropriately generated video production remains a separate future task if desired.

The working gallery contains eight static HTML records. Search, filters and the finder operate on those records. Detail, saved, compare, print and guide views demonstrate the future visitor flows, but do not supply crawlable production detail pages. Age and grey collection sections show editorial directions; they are not functioning age-filtered collections. Metadata choices in a prototype are not a substitute for the future production data model.

## Content and coverage

Keep the homepage gallery first. Definition, styling and maintenance notes support image interpretation; six concise guide previews do not replace six researched, substantive launch guides. Trust copy should continue to describe actual image generation and browser storage without claiming credentials, salon experience or results.

The supplied research supports bixie/pixie-bob head terms and selected subjects such as fine hair, thin density, curly/wavy hair, long and layered shapes, bangs, easy styling, over 50/60, 90s references and round-face references. The collection map separates measured terms from editorial breadth. Merge synonyms with shared intent and use filters for narrow combinations. Do not produce hundreds of near-identical pages from the combinations.

Research files stay separate from consumer-facing design. Export volume, difficulty and organic/feature slots are source observations. The seven files do not establish every competitor, all search demand or a current live Google US audit. Design polish, image counts and an exact-match domain cannot promise universal first place.

## Handoff requirements

Preserve the established visual hierarchy when converting to WordPress, while making the content editable through normal block and media controls. Theme files should own presentation; the companion plugin should own durable content definitions. The site must not become one giant custom HTML block or a homepage hard-coded into a PHP array.

Use real server-rendered records, crawlable links, proper collection pagination, truthful structured data and responsive image renditions. Production must support visible keyboard focus, semantic headings, dialog focus restoration, useful no-JavaScript browsing and browser zoom. Measured browser evidence belongs in the validation report; live performance and real-user metrics require a deployed site.

The complete remaining implementation and release obligations are tracked in [PRODUCTION-SCOPE.md](PRODUCTION-SCOPE.md).
