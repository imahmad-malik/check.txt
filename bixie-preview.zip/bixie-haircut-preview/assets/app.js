(() => {
  "use strict";
  if (window.__bixiePreviewInitialized) return;
  window.__bixiePreviewInitialized = true;

  const boot = () => {
    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => [
      ...root.querySelectorAll(selector),
    ];
    const cards = $$(".look-card[data-id]");
    const byId = new Map(cards.map((card) => [card.dataset.id, card]));
    const saved = new Set();
    const compared = new Set();
    const transfers = new Map();
    const previousFocus = new WeakMap();
    const storageKey = "bixie-preview:saved:v1";
    let storageAvailable = true;
    let motionChosen = false;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const announcer = $("#site-status");

    const announce = (text) => {
      if (announcer) announcer.textContent = text;
    };
    const el = (tag, className, text) => {
      const node = document.createElement(tag);
      if (className) node.className = className;
      if (text != null) node.textContent = text;
      return node;
    };
    const normalize = (value) =>
      String(value || "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
    const label = (value) =>
      String(value || "")
        .replace(/-/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase());
    const title = (card) =>
      card.dataset.title ||
      $("h3, h2", card)?.textContent.trim() ||
      "Bixie concept";
    const metadata = (card) =>
      [
        card.dataset.texture,
        card.dataset.length,
        card.dataset.fringe,
        card.dataset.colour,
      ]
        .filter(Boolean)
        .map(label)
        .join(" · ");
    const safeStorage = (action) => {
      try {
        return action(window.localStorage);
      } catch (_) {
        storageAvailable = false;
        return null;
      }
    };
    const stored = safeStorage((storage) => storage.getItem(storageKey));
    if (stored) {
      try {
        const ids = JSON.parse(stored);
        if (Array.isArray(ids))
          ids.forEach((id) => {
            if (byId.has(String(id))) saved.add(String(id));
          });
      } catch (_) {
        /* A malformed old preview value is ignored. */
      }
    }
    const persist = () =>
      safeStorage((storage) =>
        storage.setItem(storageKey, JSON.stringify([...saved])),
      );

    // Modal images are the original nodes: no image is cloned or repeated in the homepage.
    const restoreImages = (dialog) => {
      const list = transfers.get(dialog) || [];
      list.forEach(({ image, placeholder, originalClass, originalStyle }) => {
        if (placeholder.parentNode) placeholder.replaceWith(image);
        image.className = originalClass;
        if (originalStyle === null) image.removeAttribute("style");
        else image.setAttribute("style", originalStyle);
      });
      transfers.delete(dialog);
    };
    const moveImage = (card, container, dialog) => {
      const image = $("img", card);
      if (!image) return;
      const placeholder = el("span", "image-placeholder");
      placeholder.setAttribute("aria-hidden", "true");
      const rect = image.getBoundingClientRect();
      if (rect.width && rect.height)
        placeholder.style.aspectRatio = String(rect.width / rect.height);
      const record = {
        image,
        placeholder,
        originalClass: image.className,
        originalStyle: image.getAttribute("style"),
      };
      image.replaceWith(placeholder);
      image.className = "dialog-look-image";
      image.removeAttribute("style");
      container.append(image);
      const list = transfers.get(dialog) || [];
      list.push(record);
      transfers.set(dialog, list);
    };
    const closeDialog = (dialog) => {
      if (!dialog) return;
      restoreImages(dialog);
      if (dialog.open && typeof dialog.close === "function") dialog.close();
      else dialog.removeAttribute("open");
      const focus = previousFocus.get(dialog);
      if (focus?.isConnected) focus.focus({ preventScroll: true });
    };
    const openDialog = (dialog, render) => {
      if (!dialog) return;
      $$("dialog[open]").forEach((other) => {
        if (other !== dialog) closeDialog(other);
      });
      previousFocus.set(dialog, document.activeElement);
      restoreImages(dialog);
      if (render) render(dialog);
      if (!dialog.open) {
        if (typeof dialog.showModal === "function") dialog.showModal();
        else dialog.setAttribute("open", "");
      }
      $(".close-dialog, button, input, a[href]", dialog)?.focus({
        preventScroll: true,
      });
    };
    $$("dialog").forEach((dialog) => {
      dialog.addEventListener("cancel", () => restoreImages(dialog));
      dialog.addEventListener("close", () => {
        restoreImages(dialog);
        const focus = previousFocus.get(dialog);
        if (focus?.isConnected) focus.focus({ preventScroll: true });
      });
      dialog.addEventListener("click", (event) => {
        if (event.target !== dialog) return;
        const rect = dialog.getBoundingClientRect();
        if (
          event.clientX < rect.left ||
          event.clientX > rect.right ||
          event.clientY < rect.top ||
          event.clientY > rect.bottom
        )
          closeDialog(dialog);
      });
    });

    const updateSavedUI = () => {
      $$(".save-look[data-look]").forEach((button) => {
        const active = saved.has(button.dataset.look);
        button.setAttribute("aria-pressed", String(active));
        button.classList.toggle("is-saved", active);
        const card = byId.get(button.dataset.look);
        button.setAttribute(
          "aria-label",
          `${active ? "Remove" : "Save"} ${card ? title(card) : "look"}${active ? " from your shortlist" : " to your shortlist"}`,
        );
        const text = $("[data-save-label]", button);
        if (text) text.textContent = active ? "Saved" : "Save";
      });
      const count = $("#saved-count");
      if (count) count.textContent = String(saved.size);
      $("#saved-button")?.setAttribute(
        "aria-label",
        `Open your shortlist, ${saved.size} saved ${saved.size === 1 ? "look" : "looks"}`,
      );
    };
    const ensureComparison = () => {
      [...compared].forEach((id) => {
        if (!saved.has(id)) compared.delete(id);
      });
      if (!compared.size)
        [...saved].slice(0, 3).forEach((id) => compared.add(id));
    };
    const makeSummary = (card) => {
      const body = el("div", "dialog-look-body");
      body.append(
        el("h3", "", title(card)),
        el("p", "dialog-look-meta", metadata(card)),
      );
      if (card.dataset.description)
        body.append(el("p", "", card.dataset.description));
      return body;
    };
    const makeEmpty = (text) => el("p", "dialog-empty", text);
    const renderSaved = (dialog) => {
      const container = $("#saved-items", dialog);
      if (!container) return;
      restoreImages(dialog);
      container.replaceChildren();
      ensureComparison();
      if (!saved.size) {
        container.append(
          makeEmpty(
            "Your shortlist is empty. Tap the bookmark on a look to save it here.",
          ),
        );
        return;
      }
      const note = el(
        "p",
        "dialog-note",
        storageAvailable
          ? "Saved in this browser. Choose two or three looks to compare."
          : "Browser storage is unavailable; your shortlist lasts for this visit. Choose two or three looks to compare.",
      );
      container.append(note);
      [...saved].forEach((id) => {
        const card = byId.get(id);
        if (!card) return;
        const item = el("article", "saved-look dialog-look");
        const figure = el("figure", "dialog-look-figure");
        moveImage(card, figure, dialog);
        const body = makeSummary(card);
        const controls = el("div", "saved-look-controls");
        const checkLabel = el("label", "compare-choice-label");
        const checkbox = el("input", "compare-choice");
        checkbox.type = "checkbox";
        checkbox.dataset.look = id;
        checkbox.checked = compared.has(id);
        checkLabel.append(
          checkbox,
          document.createTextNode(" Select for comparison"),
        );
        const remove = el("button", "remove-saved", "Remove");
        remove.type = "button";
        remove.dataset.look = id;
        remove.setAttribute(
          "aria-label",
          `Remove ${title(card)} from your shortlist`,
        );
        controls.append(checkLabel, remove);
        body.append(controls);
        item.append(figure, body);
        container.append(item);
      });
      const feedback = el("p", "saved-feedback");
      feedback.id = "saved-feedback";
      feedback.setAttribute("role", "status");
      container.append(feedback);
    };
    const renderCompare = (dialog) => {
      const container = $("#compare-items", dialog);
      if (!container) return;
      container.replaceChildren();
      ensureComparison();
      const ids = [...compared].filter((id) => saved.has(id)).slice(0, 3);
      if (ids.length < 2) {
        container.append(
          makeEmpty(
            "Save at least two looks to compare. Your shortlist lets you select up to three.",
          ),
        );
        return;
      }
      container.append(
        el(
          "p",
          "dialog-note",
          "These are one-view AI hairstyle concepts for comparing shape, fringe and colour. Front, side and back records are not available in this HTML preview.",
        ),
      );
      const grid = el("div", "compare-grid");
      grid.tabIndex = 0;
      grid.setAttribute("role", "region");
      grid.setAttribute("aria-label", "Saved looks comparison");
      ids.forEach((id) => {
        const card = byId.get(id);
        const item = el("article", "compare-look dialog-look");
        const figure = el("figure", "dialog-look-figure");
        moveImage(card, figure, dialog);
        const body = makeSummary(card);
        const list = el("dl", "look-facts");
        [
          ["Texture / density", card.dataset.texture],
          ["Length", card.dataset.length],
          ["Fringe", card.dataset.fringe],
          ["Colour", card.dataset.colour],
        ].forEach(([key, value]) =>
          list.append(el("dt", "", key), el("dd", "", label(value))),
        );
        body.append(list);
        item.append(figure, body);
        grid.append(item);
      });
      container.append(grid);
    };
    const renderLook = (dialog, id) => {
      const container = $("#look-detail", dialog);
      const card = byId.get(id);
      if (!container || !card) return;
      container.replaceChildren();
      const figure = el("figure", "dialog-look-figure");
      moveImage(card, figure, dialog);
      const body = makeSummary(card);
      body.append(
        el(
          "p",
          "dialog-note",
          "Original AI concept image. This preview shows one view, rather than a verified salon result or a complete front / side / back record.",
        ),
      );
      const salon = el("div", "salon-notes");
      salon.append(el("h3", "", "Bring the shape to your consultation"));
      salon.append(
        el(
          "p",
          "",
          card.dataset.styling ||
            "Discuss the crown length, weight around the ears and preferred fringe with your stylist. Ask how the shape will behave with your natural texture and daily routine.",
        ),
      );
      salon.append(
        el(
          "p",
          "",
          card.dataset.maintenance ||
            "A stylist can recommend a trim interval and styling routine after assessing your hair. Maintenance varies with the chosen length and finish.",
        ),
      );
      body.append(salon);
      const save = el(
        "button",
        "button save-look",
        saved.has(id) ? "Remove from shortlist" : "Save to shortlist",
      );
      save.type = "button";
      save.dataset.look = id;
      const saveLabel = el("span", "");
      saveLabel.dataset.saveLabel = "";
      saveLabel.textContent = saved.has(id) ? "Saved" : "Save";
      save.replaceChildren(saveLabel);
      body.append(save);
      container.append(figure, body);
      updateSavedUI();
    };
    const renderPrint = (dialog) => {
      const container = $("#print-items", dialog);
      if (!container) return;
      container.replaceChildren();
      if (!saved.size) {
        container.append(
          makeEmpty("Save a look to create your consultation sheet."),
        );
        return;
      }
      container.append(
        el(
          "p",
          "dialog-note",
          "Consultation shortlist · Original AI hairstyle concepts, not photographs of finished salon cuts. All images are one-view previews.",
        ),
      );
      const list = el("div", "print-look-grid");
      [...saved].forEach((id) => {
        const card = byId.get(id);
        const item = el("article", "print-look dialog-look");
        const figure = el("figure", "dialog-look-figure");
        moveImage(card, figure, dialog);
        const body = makeSummary(card);
        const reference = el("p", "print-look-reference");
        reference.append(el("strong", "", `Look ID: ${id}`), el("br", ""));
        const localURL = new URL(window.location.href);
        localURL.hash = `look=${encodeURIComponent(id)}`;
        const link = el("a", "preview-look-url open-look", localURL.href);
        link.href = localURL.href;
        link.dataset.look = id;
        reference.append(link);
        body.append(
          reference,
          el(
            "p",
            "print-look-notes",
            card.dataset.styling ||
              "Discuss the crown, nape, fringe and daily styling routine with your stylist.",
          ),
        );
        item.append(figure, body);
        list.append(item);
      });
      container.append(
        list,
        el(
          "p",
          "print-consultation-note",
          "Ask your stylist: How will this shape suit my natural texture, growth pattern and styling time? What will the daily routine and trim schedule involve?",
        ),
      );
    };

    const filterNames = ["texture", "length", "fringe", "colour"];
    const filters = Object.fromEntries(
      filterNames.map((name) => [name, $(`#${name}-filter`)]),
    );
    const gallerySearch = $("#gallery-search");
    const sortFilter = $("#sort-filter");
    const originalIndex = new Map(cards.map((card, index) => [card, index]));
    const applyFilters = () => {
      const query = normalize(gallerySearch?.value);
      const terms = query.split(/\s+/).filter(Boolean);
      let count = 0;
      cards.forEach((card) => {
        const text = normalize(
          [
            title(card),
            card.dataset.description,
            ...filterNames.map((name) => card.dataset[name]),
          ].join(" "),
        );
        const matches =
          terms.every((term) => text.includes(term)) &&
          filterNames.every((name) => {
            const choice = normalize(filters[name]?.value);
            return (
              !choice ||
              choice === "all" ||
              normalize(card.dataset[name])
                .split(/[,|]/)
                .map((value) => value.trim())
                .includes(choice)
            );
          });
        card.hidden = !matches;
        if (matches) count += 1;
      });
      const sort = normalize(sortFilter?.value);
      const ordered = [...cards].sort((a, b) => {
        if (["az", "a-z", "title", "name"].includes(sort))
          return title(a).localeCompare(title(b));
        if (["za", "z-a"].includes(sort))
          return title(b).localeCompare(title(a));
        if (["newest", "latest"].includes(sort))
          return Number(b.dataset.order || 0) - Number(a.dataset.order || 0);
        if (["shortest", "longest"].includes(sort)) {
          const length = { short: 0, medium: 1, long: 2 };
          return (
            ((length[a.dataset.length] ?? 0) -
              (length[b.dataset.length] ?? 0)) *
            (sort === "longest" ? -1 : 1)
          );
        }
        return (
          Number(a.dataset.order || originalIndex.get(a)) -
          Number(b.dataset.order || originalIndex.get(b))
        );
      });
      const parent = cards[0]?.parentElement;
      if (parent && ordered.every((card) => card.parentElement === parent))
        ordered.forEach((card) => parent.append(card));
      const countNode = $("#result-count");
      if (countNode)
        countNode.textContent = `${count} ${count === 1 ? "look" : "looks"}${count !== cards.length ? ` of ${cards.length}` : ""}`;
      const empty = $("#gallery-empty");
      if (empty) empty.hidden = count !== 0;
      return count;
    };
    const setFilter = (name, value) => {
      const control = filters[name];
      if (!control) return;
      const valid = [...control.options].find(
        (option) => normalize(option.value) === normalize(value),
      );
      control.value = valid ? valid.value : control.options[0]?.value || "";
    };
    const resetFilters = () => {
      if (gallerySearch) gallerySearch.value = "";
      filterNames.forEach((name) => setFilter(name, ""));
      if (sortFilter) sortFilter.value = sortFilter.options[0]?.value || "";
      applyFilters();
    };
    const scrollToGallery = () => {
      const gallery = $("#gallery");
      gallery?.scrollIntoView({
        behavior: document.body.classList.contains("motion-paused")
          ? "auto"
          : "smooth",
        block: "start",
      });
    };
    Object.values(filters).forEach((control) =>
      control?.addEventListener("change", applyFilters),
    );
    sortFilter?.addEventListener("change", applyFilters);
    gallerySearch?.addEventListener("input", applyFilters);
    $("#clear-filters")?.addEventListener("click", resetFilters);
    $("#finder-form")?.addEventListener("submit", (event) => {
      event.preventDefault();
      if (gallerySearch) gallerySearch.value = "";
      filterNames.forEach((name) => setFilter(name, ""));
      ["texture", "length", "fringe"].forEach((name) =>
        setFilter(
          name,
          event.currentTarget.elements.namedItem(name)?.value || "",
        ),
      );
      const count = applyFilters();
      const status = $("#finder-status");
      if (status)
        status.textContent = count
          ? `${count} preview ${count === 1 ? "look matches" : "looks match"} your choices. Explore them in the gallery below.`
          : "This eight-look preview has no exact match for that combination. Clear a filter to explore nearby shapes.";
      scrollToGallery();
      announce(`${count} gallery looks match your choices.`);
    });

    const menuToggle = $("#menu-toggle");
    const navigation = $("#site-nav");
    const setMenu = (expanded) => {
      menuToggle?.setAttribute("aria-expanded", String(expanded));
      navigation?.classList.toggle("is-open", expanded);
      document.body.classList.toggle("menu-open", expanded);
    };
    menuToggle?.addEventListener("click", () =>
      setMenu(menuToggle.getAttribute("aria-expanded") !== "true"),
    );
    navigation?.addEventListener("click", (event) => {
      if (event.target.closest("a")) setMenu(false);
    });
    document.addEventListener("keydown", (event) => {
      if (
        event.key === "Escape" &&
        menuToggle?.getAttribute("aria-expanded") === "true"
      ) {
        setMenu(false);
        menuToggle.focus();
      }
      if (
        event.key === "Tab" &&
        menuToggle?.getAttribute("aria-expanded") === "true" &&
        navigation
      ) {
        const focusable = [
          menuToggle,
          ...$$(
            "a[href], button:not([disabled]), input:not([disabled])",
            navigation,
          ),
        ].filter((node) => node.getClientRects().length);
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    });
    document.addEventListener("click", (event) => {
      if (
        menuToggle?.getAttribute("aria-expanded") === "true" &&
        !navigation?.contains(event.target) &&
        !menuToggle.contains(event.target)
      )
        setMenu(false);
    });
    window.addEventListener(
      "resize",
      () => {
        if (
          menuToggle &&
          window.getComputedStyle(menuToggle).display === "none"
        )
          setMenu(false);
      },
      { passive: true },
    );

    const resumeAfterMotion = new Set();
    let filmHasError = false;
    const updateFilmButton = () => {
      const film = $("#editorial-film");
      const button = $("#film-play");
      if (!film || !button) return;
      const playing = !film.paused && !film.ended && !filmHasError;
      button.setAttribute("aria-pressed", String(playing));
      button.setAttribute(
        "aria-label",
        playing
          ? "Pause the editorial motion film"
          : "Play the editorial motion film",
      );
      const text = $("[data-film-label]", button);
      if (text) text.textContent = playing ? "Pause film" : "Play film";
      button.classList.toggle("is-playing", playing);
    };
    const showFilmFeedback = (text) => {
      const video = $("#editorial-film");
      if (!video) return;
      let status = $("#film-status");
      if (!status) {
        status = el("p", "film-status");
        status.id = "film-status";
        status.setAttribute("role", "status");
        video.parentElement.append(status);
      }
      status.textContent = text;
      status.hidden = !text;
      if (text) announce(text);
    };
    const playVideo = (video) => {
      if (video.id === "editorial-film" && filmHasError) return;
      const playing = video.play();
      if (playing && typeof playing.catch === "function")
        playing.catch((error) => {
          if (error.name === "AbortError" && video.paused && !filmHasError)
            return;
          if (video.id === "editorial-film") {
            filmHasError = true;
            video.pause();
            showFilmFeedback(
              "The motion study could not start. Use Play film to try again; the original still images remain available.",
            );
          } else
            announce(
              "The motion film could not start. The original still images remain available.",
            );
          updateFilmButton();
        });
    };
    const setMotion = (paused) => {
      document.body.classList.toggle("motion-paused", paused);
      $$(".motion-toggle").forEach((button) => {
        button.setAttribute("aria-pressed", String(paused));
        button.setAttribute(
          "aria-label",
          paused ? "Enable page motion" : "Pause page motion",
        );
        const text = $("[data-motion-label]", button);
        if (text) text.textContent = paused ? "Resume motion" : "Pause motion";
        else button.textContent = paused ? "Resume motion" : "Pause motion";
      });
      $$("video").forEach((video) => {
        if (paused) {
          if (!video.paused) resumeAfterMotion.add(video);
          video.pause();
        } else if (
          (resumeAfterMotion.has(video) || video.autoplay) &&
          !video.closest(".offscreen")
        ) {
          resumeAfterMotion.delete(video);
          playVideo(video);
        }
      });
      if (paused)
        $$(".reveal").forEach((node) => node.classList.add("is-visible"));
      updateFilmButton();
    };
    setMotion(reduceMotion.matches);
    reduceMotion.addEventListener?.("change", (event) => {
      if (!motionChosen) setMotion(event.matches);
    });
    const film = $("#editorial-film");
    film?.addEventListener("play", () => {
      showFilmFeedback("");
      updateFilmButton();
    });
    film?.addEventListener("pause", updateFilmButton);
    film?.addEventListener("ended", updateFilmButton);
    film?.addEventListener(
      "error",
      () => {
        filmHasError = true;
        resumeAfterMotion.delete(film);
        delete film.dataset.resumeWhenVisible;
        film.pause();
        const code = film.error?.code;
        const message =
          code === 3
            ? "This browser could not decode the motion study."
            : code === 4
              ? "The motion study format or source is unavailable in this browser."
              : "The motion study could not load.";
        showFilmFeedback(
          `${message} The original still images remain available.`,
        );
        updateFilmButton();
      },
      true,
    );
    $("#film-play")?.addEventListener("click", () => {
      if (!film) return;
      if (!film.paused) film.pause();
      else {
        if (!film.getAttribute("src") && !film.querySelector("source[src]")) {
          showFilmFeedback(
            "The editorial film is not available in this preview. The original still images remain available.",
          );
          return;
        }
        if (filmHasError || film.error) {
          filmHasError = false;
          film.load();
        }
        showFilmFeedback("");
        motionChosen = true;
        setMotion(false);
        playVideo(film);
      }
    });
    if ("IntersectionObserver" in window) {
      const revealObserver = new IntersectionObserver(
        (entries) =>
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              revealObserver.unobserve(entry.target);
            }
          }),
        { threshold: 0.06 },
      );
      $$(".reveal").forEach((node) => revealObserver.observe(node));
      const motionObserver = new IntersectionObserver(
        (entries) =>
          entries.forEach((entry) => {
            entry.target.classList.toggle("offscreen", !entry.isIntersecting);
            $$("video", entry.target).forEach((video) => {
              if (!entry.isIntersecting) {
                if (!video.paused || video.autoplay)
                  video.dataset.resumeWhenVisible = "true";
                video.pause();
              } else if (
                video.dataset.resumeWhenVisible === "true" &&
                !document.body.classList.contains("motion-paused")
              ) {
                delete video.dataset.resumeWhenVisible;
                playVideo(video);
              }
            });
          }),
        { rootMargin: "100px", threshold: 0 },
      );
      const motionSections = new Set([
        ...$$(".motion-section"),
        ...$$("video")
          .map((video) => video.closest("section"))
          .filter(Boolean),
      ]);
      motionSections.forEach((section) => motionObserver.observe(section));
    } else $$(".reveal").forEach((node) => node.classList.add("is-visible"));

    let guideData = {};
    try {
      guideData = JSON.parse($("#guide-data")?.textContent || "{}");
    } catch (_) {
      /* The homepage remains usable if optional guide data is absent. */
    }
    const renderGuide = (dialog, id) => {
      const container = $("#guide-content", dialog);
      if (!container) return;
      const guide = Array.isArray(guideData)
        ? guideData.find((item) => item.id === id)
        : guideData[id];
      container.replaceChildren();
      if (!guide) {
        container.append(
          el("h2", "", "Guide preview"),
          makeEmpty("This guide is not included in the HTML preview."),
        );
        return;
      }
      if (guide.eyebrow || guide.kicker)
        container.append(el("p", "eyebrow", guide.eyebrow || guide.kicker));
      container.append(el("h2", "", guide.title || "Guide preview"));
      if (guide.intro) container.append(el("p", "guide-intro", guide.intro));
      const paragraphs = guide.paragraphs || guide.body || [];
      (Array.isArray(paragraphs) ? paragraphs : [paragraphs]).forEach(
        (text) => {
          if (text) container.append(el("p", "", text));
        },
      );
      (guide.sections || []).forEach((section) => {
        if (section.heading || section.title)
          container.append(el("h3", "", section.heading || section.title));
        const body = section.paragraphs || section.body || section.text || [];
        (Array.isArray(body) ? body : [body]).forEach((text) => {
          if (text) container.append(el("p", "", text));
        });
        if (section.items) {
          const list = el("ul", "guide-tips");
          section.items.forEach((text) => list.append(el("li", "", text)));
          container.append(list);
        }
      });
      if (guide.tips?.length) {
        const list = el("ul", "guide-tips");
        guide.tips.forEach((text) => list.append(el("li", "", text)));
        container.append(list);
      }
      if (
        [
          "what-is-bixie",
          "stylist",
          "styling",
          "fine-thin",
          "references",
          "grow-out",
        ].includes(id)
      )
        container.append(
          el(
            "p",
            "dialog-note",
            "Editorial guide preview. Individual haircut advice should be tailored during a consultation with a qualified stylist.",
          ),
        );
    };

    document.addEventListener("change", (event) => {
      const checkbox = event.target.closest(".compare-choice[data-look]");
      if (!checkbox) return;
      if (
        checkbox.checked &&
        compared.size >= 3 &&
        !compared.has(checkbox.dataset.look)
      ) {
        checkbox.checked = false;
        const feedback = $("#saved-feedback");
        if (feedback)
          feedback.textContent =
            "Choose up to three looks. Deselect one to choose another.";
        return;
      }
      if (checkbox.checked) compared.add(checkbox.dataset.look);
      else compared.delete(checkbox.dataset.look);
      const feedback = $("#saved-feedback");
      if (feedback)
        feedback.textContent = `${compared.size} ${compared.size === 1 ? "look" : "looks"} selected for comparison.`;
    });
    document.addEventListener("click", (event) => {
      const target = event.target.closest("button, a");
      if (!target) return;
      if (target.matches(".close-dialog")) {
        closeDialog(
          document.getElementById(target.dataset.dialog || "") ||
            target.closest("dialog"),
        );
      } else if (
        target.matches(".save-look[data-look], .remove-saved[data-look]")
      ) {
        event.preventDefault();
        const id = target.dataset.look;
        if (!byId.has(id)) return;
        if (saved.has(id)) {
          saved.delete(id);
          compared.delete(id);
        } else saved.add(id);
        persist();
        updateSavedUI();
        announce(
          `${title(byId.get(id))} ${saved.has(id) ? "saved to" : "removed from"} your shortlist.${storageAvailable ? "" : " Browser storage is unavailable; this shortlist lasts for your visit."}`,
        );
        const dialog = $("#saved-dialog");
        if (dialog?.open) {
          renderSaved(dialog);
          if (!dialog.contains(document.activeElement))
            $(".close-dialog", dialog)?.focus({ preventScroll: true });
        }
      } else if (target.id === "saved-button") {
        openDialog($("#saved-dialog"), renderSaved);
      } else if (target.id === "clear-saved") {
        saved.clear();
        compared.clear();
        persist();
        updateSavedUI();
        const dialog = $("#saved-dialog");
        if (dialog?.open) renderSaved(dialog);
        announce("Your shortlist has been cleared.");
      } else if (
        target.id === "compare-button" ||
        target.id === "compare-saved"
      ) {
        openDialog($("#compare-dialog"), renderCompare);
      } else if (target.matches(".open-look[data-look]")) {
        event.preventDefault();
        openDialog($("#look-dialog"), (dialog) =>
          renderLook(dialog, target.dataset.look),
        );
      } else if (target.id === "print-saved") {
        openDialog($("#print-dialog"), renderPrint);
      } else if (target.id === "print-now") {
        if (saved.size) window.print();
        else announce("Save a look before printing your consultation sheet.");
      } else if (target.matches(".motion-toggle")) {
        motionChosen = true;
        setMotion(!document.body.classList.contains("motion-paused"));
      } else if (target.id === "search-button") {
        scrollToGallery();
        gallerySearch?.focus({ preventScroll: true });
      } else if (target.matches("[data-collection]")) {
        event.preventDefault();
        resetFilters();
        filterNames.forEach((name) => {
          if (target.dataset[name]) setFilter(name, target.dataset[name]);
        });
        const count = applyFilters();
        scrollToGallery();
        announce(
          `${count} ${count === 1 ? "look" : "looks"} in this preview collection.`,
        );
      } else if (target.matches(".open-guide[data-guide]")) {
        event.preventDefault();
        openDialog($("#guide-dialog"), (dialog) =>
          renderGuide(dialog, target.dataset.guide),
        );
      } else if (target.id === "coverage-toggle") {
        openDialog($("#coverage-dialog"));
      }
    });
    updateSavedUI();
    applyFilters();
    updateFilmButton();
    document.documentElement.classList.add("js-ready");
    const openHashLook = () => {
      const id = new URLSearchParams(window.location.hash.slice(1)).get("look");
      if (byId.has(id))
        openDialog($("#look-dialog"), (dialog) => renderLook(dialog, id));
    };
    window.addEventListener("hashchange", openHashLook);
    openHashLook();
  };
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  else boot();
})();
