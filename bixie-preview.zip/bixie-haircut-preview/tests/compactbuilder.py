#!/usr/bin/env python3
"""Build a smaller, completely embedded copy without changing source assets.

This is a delivery fallback for viewers with size limits. It retains the exact
source HTML, CSS and JS, substituting only compressed derivatives and correct
image dimensions. Original files and the full quality release remain intact.

Requires ffmpeg/ffprobe and Python fonttools with Brotli support. In this machine
the missing Brotli dependency was installed in /tmp/bixie-compact-python; rerun:
  PYTHONPATH=/tmp/bixie-compact-python python3 tests/compactbuilder.py
The /tmp dependency is disposable; install fonttools[woff] in a task-local
Python environment when reproducing on another machine.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from fontTools import subset
from fontTools.ttLib import TTFont
import base64
import hashlib
import json
import mimetypes
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT.parent / "preview-light.html"
WIDTH = 480
QUALITY = 60


def run(command):
    subprocess.run(command, check=True, stdout=subprocess.DEVNULL,
                   stderr=subprocess.PIPE)


def data_uri(path):
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return "data:" + mime + ";base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def dimensions(path):
    result = subprocess.run([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height", "-of", "json", str(path)
    ], check=True, capture_output=True, text=True)
    stream = json.loads(result.stdout)["streams"][0]
    return stream["width"], stream["height"]


def main():
    html = (ROOT / "source.html").read_text()
    css = (ROOT / "assets/style.css").read_text()
    js = (ROOT / "assets/app.js").read_text()
    records = json.loads((ROOT / "assets/image-manifest.json").read_text())["records"]
    image_paths = set(re.findall(r'(?:src|poster)="(assets/images/[^"]+)"', html))
    sources = {r["display_file"]: ROOT / r["source_file"] for r in records}
    assert len(image_paths) == 26 and image_paths <= sources.keys()
    original_hashes = {p: hashlib.sha256(sources[p].read_bytes()).hexdigest() for p in image_paths}
    derivative_sizes = {}
    image_sizes = {}
    font_sizes = {}

    with tempfile.TemporaryDirectory(prefix="bixie-compact-", dir="/tmp") as temp:
        work = Path(temp)
        replacements = {}

        def compress_image(display_path):
            source = sources[display_path]
            target = work / Path(display_path).name
            # Scaling only: no crop, retouching, filters, or new image generation.
            run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                 "-i", str(source), "-vf", f"scale='min({WIDTH},iw)':-1",
                 "-frames:v", "1", "-c:v", "libwebp", "-quality", str(QUALITY),
                 "-compression_level", "6", "-threads", "1", str(target)])
            return display_path, target, dimensions(target)

        with ThreadPoolExecutor(max_workers=4) as pool:
            for name, target, size in pool.map(compress_image, sorted(image_paths)):
                replacements[name] = target
                derivative_sizes[name] = target.stat().st_size
                image_sizes[name] = size

        video = work / "editorial-motion.mp4"
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
             "-i", str(ROOT / "assets/editorial-motion.mp4"),
             "-vf", "scale=480:270,fps=15", "-an", "-c:v", "libx264",
             "-preset", "slow", "-crf", "32", "-pix_fmt", "yuv420p",
             "-threads", "2", "-movflags", "+faststart", str(video)])
        replacements["assets/editorial-motion.mp4"] = video

        # Keep all seven real font faces; strip glyphs that the preview never uses.
        # Latin-1 plus source characters preserve text, controls and star symbols.
        unicode_points = set(range(0x20, 0x100)) | {ord(c) for c in html + css + js}
        font_paths = re.findall(r'url\([\'\"]?(fonts/[^\)\'\"]+)', css)
        assert len(font_paths) == len(set(font_paths)) == 7
        for font_path in font_paths:
            original = ROOT / "assets" / font_path
            target = work / original.name
            font = TTFont(original)
            options = subset.Options()
            options.flavor = "woff2"
            options.layout_features = ["*"]
            subsetter = subset.Subsetter(options=options)
            subsetter.populate(unicodes=unicode_points)
            subsetter.subset(font)
            font.save(target)
            font.close()
            replacements["assets/" + font_path] = target
            font_sizes[font_path] = target.stat().st_size

        def inline_css_asset(match):
            path = "assets/" + match.group(1)
            return 'url("' + data_uri(replacements.get(path, ROOT / path)) + '")'

        css = re.sub(r'url\([\'\"]?([^\)\'\"]+)[\'\"]?\)', inline_css_asset, css)
        html = re.sub(r'<link\b[^>]*rel="preload"[^>]*>', "", html)
        html = re.sub(r'<link\b[^>]*href="assets/style.css"[^>]*>', lambda _: "<style>\n" + css + "\n</style>", html)
        html = re.sub(r'<script\b[^>]*src="assets/app.js"[^>]*>\s*</script>', lambda _: "<script>\n" + js + "\n</script>", html)

        def update_dimensions(match):
            tag = match.group(0)
            path = re.search(r'src="(assets/images/[^"]+)"', tag).group(1)
            width, height = image_sizes[path]
            tag = re.sub(r'width="\d+"', f'width="{width}"', tag)
            return re.sub(r'height="\d+"', f'height="{height}"', tag)

        html = re.sub(r'<img\b[^>]*src="assets/images/[^"]+"[^>]*>', update_dimensions, html)

        def inline_html_asset(match):
            path = match.group(2)
            return match.group(1) + '="' + data_uri(replacements.get(path, ROOT / path)) + '"'

        html = re.sub(r'(src|poster|href)="(assets/[^\"]+)"', inline_html_asset, html)
        assert not re.search(r'(src|poster|href)="assets/', html)
        assert 'url("fonts/' not in html
        OUTPUT.write_text(html)
        for path, original_hash in original_hashes.items():
            assert hashlib.sha256(sources[path].read_bytes()).hexdigest() == original_hash

        report = {
            "output": str(OUTPUT), "html_bytes": OUTPUT.stat().st_size,
            "html_sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
            "source_images_unchanged": True, "image_count": len(image_paths),
            "image_width_limit": WIDTH, "webp_quality": QUALITY,
            "image_bytes_total": sum(derivative_sizes.values()),
            "video_bytes": video.stat().st_size,
            "video": {"width": 480, "height": 270, "fps": 15, "crf": 32,
                      "duration_seconds": 12, "audio": False},
            "font_faces": len(font_paths), "font_bytes_total": sum(font_sizes.values()),
            "image_dimensions": image_sizes, "image_bytes": derivative_sizes,
            "font_bytes": font_sizes,
            "limitations": "Compressed preview images and video use lower resolution. The actual chat viewer is not directly accessible."
        }
        (ROOT / "tests/compact-build-report.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({k: report[k] for k in ["output", "html_bytes", "image_count", "image_bytes_total", "video_bytes", "font_faces", "font_bytes_total"]}))


if __name__ == "__main__":
    main()
