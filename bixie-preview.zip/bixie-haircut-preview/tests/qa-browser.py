#!/usr/bin/env python3
"""Actual browser layout/accessibility smoke checks for the HTML design preview.

Run with a local static server, Python Playwright, Chromium and optionally axe:
  python tests/qa-browser.py --url http://127.0.0.1:8765 --axe /tmp/bixie-axe/axe.min.js
Outputs are observations at the tested viewport, not live SEO/CWV claims.
"""
import argparse
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
SHOTS = ROOT / 'screenshots'

GEOMETRY = """() => ({
 width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth,
 bodyWidth: document.body.scrollWidth, scrollHeight: document.documentElement.scrollHeight,
 horizontalOverflow: document.documentElement.scrollWidth > innerWidth + 1,
 images: [...document.images].map(i => ({src:i.getAttribute('src'), loaded:i.complete && i.naturalWidth>0, alt:i.alt})),
 duplicates: [...new Set([...document.images].map(i=>i.src))].filter(src=>[...document.images].filter(i=>i.src===src).length>1),
 outside: [...document.querySelectorAll('body *')].filter(el => {
  let r=el.getBoundingClientRect(), s=getComputedStyle(el);
  return r.width && r.height && s.position!=='fixed' && (r.right>innerWidth+1 || r.left< -1) && !el.closest('.ribbon-window,.compare-grid,dialog:not([open]),.sr-only,.skip-link');
 }).slice(0,20).map(el=>({tag:el.tagName,cls:el.className, text:el.textContent?.slice(0,70), left:el.getBoundingClientRect().left,right:el.getBoundingClientRect().right}))
})"""

def axe(page, axe_path):
    if not axe_path:
        return {'notRun': 'Pass --axe path to an integrity-verified axe.min.js'}
    page.add_script_tag(path=axe_path)
    result = page.evaluate("""async () => {
      const r=await axe.run(document, {runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}});
      return {violations:r.violations.map(v=>({id:v.id,impact:v.impact,description:v.description,help:v.help,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary,html:n.html}))})),incomplete:r.incomplete.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))})),passes:r.passes.length};
    }""")
    return result

def force_images(page):
    page.evaluate("() => [...document.images].forEach(i => i.loading='eager')")
    page.wait_for_timeout(1000)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--url',default='http://127.0.0.1:8765')
    parser.add_argument('--axe')
    parser.add_argument('--report',default='browser-observations.json')
    args=parser.parse_args()
    SHOTS.mkdir(exist_ok=True)
    observations={'url':args.url,'axeVersion':'4.14.0' if args.axe else None,'pages':{},'dialogs':{},'reducedMotion':{},'limits':[
        'Checks use local Chromium at the listed viewports, not live search rankings or Core Web Vitals.',
        '200% zoom is tested as the equivalent 720 CSS-pixel viewport rendered at scale 2, not a browser UI zoom command.',
        'Automated axe checks do not establish full accessibility conformance; image/video overlay contrast and decorative glyph checks require visual review.',
        'The editorial motion clip contains silent H264 video only, as confirmed separately with ffprobe; no speech captions are applicable.'
    ]}
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        for name,width,height in [('desktop',1440,1000),('tablet',768,1024),('phone',390,844),('small-phone',320,720)]:
            context=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
            page=context.new_page()
            console=[]; failures=[]
            page.on('pageerror',lambda error: console.append(str(error)))
            page.on('response',lambda response: failures.append({'status':response.status,'url':response.url}) if response.status >=400 else None)
            page.goto(args.url,wait_until='networkidle')
            force_images(page)
            page.screenshot(path=str(SHOTS/f'{name}-hero.png'))
            for section in ['#gallery','#all-angles','#finder','#guides']:
                page.locator(section).scroll_into_view_if_needed()
                page.wait_for_timeout(100)
                page.screenshot(path=str(SHOTS/f'{name}-{section[1:]}.png'))
            data=page.evaluate(GEOMETRY)
            data.update(consoleErrors=console,failedResponses=failures,axe=axe(page,args.axe))
            observations['pages'][name]=data
            page.locator('#gallery').scroll_into_view_if_needed()
            for selector in ['.look-card .save-look']:
                buttons=page.locator(selector)
                for i in range(min(buttons.count(),3)):
                    buttons.nth(i).click()
            page.locator('#saved-button').click()
            observations['dialogs'][f'{name}-saved']=page.evaluate("() => {let d=document.querySelector('#saved-dialog');return {width:d.clientWidth,scrollWidth:d.scrollWidth,height:d.clientHeight,scrollHeight:d.scrollHeight,activeElement:document.activeElement.outerHTML}}")
            page.screenshot(path=str(SHOTS/f'{name}-saved.png'))
            observations['dialogs'][f'{name}-saved']['axe']=axe(page,args.axe)
            page.locator('#compare-saved').click()
            observations['dialogs'][f'{name}-compare']=page.evaluate("() => {let d=document.querySelector('#compare-dialog'),g=d.querySelector('.compare-grid');return {width:d.clientWidth,scrollWidth:d.scrollWidth,height:d.clientHeight,scrollHeight:d.scrollHeight,gridWidth:g?.clientWidth,gridScrollWidth:g?.scrollWidth,activeElement:document.activeElement.outerHTML}}")
            page.screenshot(path=str(SHOTS/f'{name}-compare.png'))
            observations['dialogs'][f'{name}-compare']['axe']=axe(page,args.axe)
            page.keyboard.press('Escape')
            # Programmatically open through the real click handler; test dialog geometry and focus.
            page.locator('.open-look[data-look="soft-layered"]').first.click()
            observations['dialogs'][f'{name}-look']=page.evaluate("() => {let d=document.querySelector('#look-dialog');return {width:d.clientWidth,scrollWidth:d.scrollWidth,height:d.clientHeight,scrollHeight:d.scrollHeight,activeElement:document.activeElement.outerHTML}}")
            page.screenshot(path=str(SHOTS/f'{name}-look.png'))
            observations['dialogs'][f'{name}-look']['axe']=axe(page,args.axe)
            page.keyboard.press('Escape')
            # Only the page should remain when the modal closes; images should be restored.
            observations['dialogs'][f'{name}-closed']=page.evaluate("() => ({open:document.querySelectorAll('dialog[open]').length,modalImages:document.querySelectorAll('dialog img').length,cardImages:document.querySelectorAll('.look-card img').length,focused:document.activeElement.outerHTML})")
            page.locator('.open-guide[data-guide="stylist"]').first.click()
            observations['dialogs'][f'{name}-guide']=page.evaluate("() => {let d=document.querySelector('#guide-dialog');return {width:d.clientWidth,scrollWidth:d.scrollWidth,height:d.clientHeight,scrollHeight:d.scrollHeight,activeElement:document.activeElement.outerHTML}}")
            observations['dialogs'][f'{name}-guide']['axe']=axe(page,args.axe)
            page.screenshot(path=str(SHOTS/f'{name}-guide-dialog.png'))
            page.keyboard.press('Escape')
            if page.locator('#menu-toggle').is_visible():
                page.locator('#menu-toggle').click()
                observations['dialogs'][f'{name}-menu']={'axe':axe(page,args.axe)}
                page.screenshot(path=str(SHOTS/f'{name}-menu.png'))
                page.keyboard.press('Escape')
                observations['dialogs'][f'{name}-menu']['afterEscape']=page.evaluate("() => ({expanded:document.querySelector('#menu-toggle').getAttribute('aria-expanded'),focused:document.activeElement.id})")
            context.close()
        # Browser 200% desktop zoom produces a 720px CSS viewport at 1440px output.
        # Emulate that reflow geometry; this is not an OS/browser UI zoom command.
        context=browser.new_context(viewport={'width':720,'height':500},device_scale_factor=2,reduced_motion='reduce')
        page=context.new_page();page.goto(args.url,wait_until='networkidle')
        force_images(page)
        page.screenshot(path=str(SHOTS/'desktop-200percent.png'))
        observations['pages']['desktop-200percent-reflow-equivalent']=page.evaluate(GEOMETRY)
        observations['pages']['desktop-200percent-reflow-equivalent']['axe']=axe(page,args.axe)
        observations['reducedMotion']=page.evaluate("() => ({preference:matchMedia('(prefers-reduced-motion: reduce)').matches,bodyPaused:document.body.classList.contains('motion-paused'),ribbonAnimation:getComputedStyle(document.querySelector('.ribbon-track')).animationName,ribbonState:getComputedStyle(document.querySelector('.ribbon-track')).animationPlayState,videos:[...document.querySelectorAll('video')].map(v=>({paused:v.paused,autoplay:v.autoplay})),motionButton:document.querySelector('.motion-toggle')?.getAttribute('aria-pressed')})")
        context.close();browser.close()
    output=ROOT/args.report
    output.write_text(json.dumps(observations,indent=2))
    print(json.dumps({'report':str(output),'pages':{k:{'overflow':v.get('horizontalOverflow'),'badImages':len([i for i in v.get('images',[]) if not i['loaded']]),'axeViolations':len(v.get('axe',{}).get('violations',[]))} for k,v in observations['pages'].items()},'dialogs':{k:{'overflow':v.get('scrollWidth',0)>v.get('width',0)+1,'axeViolations':len(v.get('axe',{}).get('violations',[]))} for k,v in observations['dialogs'].items()},'reducedMotion':observations['reducedMotion']},indent=2))

if __name__ == '__main__':
    main()
