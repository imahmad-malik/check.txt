#!/usr/bin/env python3
"""Verify the real MP4 decodes and the motion controls pause/resume it."""
import argparse
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

def state(page):
    return page.evaluate("""() => {const v=document.querySelector('#editorial-film'),r=getComputedStyle(document.querySelector('.ribbon-track'));return {currentTime:v.currentTime,duration:v.duration,paused:v.paused,readyState:v.readyState,error:v.error?.code||null,buttonPressed:document.querySelector('#film-play').getAttribute('aria-pressed'),bodyMotionPaused:document.body.classList.contains('motion-paused'),ribbonAnimation:r.animationName,ribbonState:r.animationPlayState,ribbonTransform:r.transform};}""")

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--url',default='http://127.0.0.1:8765')
    args=parser.parse_args()
    result={'url':args.url,'states':{},'consoleErrors':[],'failedResponses':[]}
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='no-preference')
        page=context.new_page()
        page.on('pageerror',lambda e:result['consoleErrors'].append(str(e)))
        page.on('response',lambda r:result['failedResponses'].append({'status':r.status,'url':r.url}) if r.status>=400 else None)
        page.goto(args.url,wait_until='networkidle')
        page.locator('.film-overlay').scroll_into_view_if_needed()
        page.locator('#film-play').click()
        page.wait_for_function("() => !document.querySelector('#editorial-film').paused && document.querySelector('#editorial-film').currentTime>0.4")
        result['states']['playing']=state(page)
        assert result['states']['playing']['error'] is None
        assert result['states']['playing']['buttonPressed']=='true'
        page.locator('#film-play').click()
        page.wait_for_function("() => document.querySelector('#editorial-film').paused && document.querySelector('#film-play').getAttribute('aria-pressed')==='false'")
        result['states']['pausedByButton']=state(page)
        assert result['states']['pausedByButton']['paused']
        page.locator('#film-play').click()
        page.wait_for_timeout(250)
        page.locator('#moving-edit').scroll_into_view_if_needed()
        page.wait_for_timeout(150)
        result['states']['ribbonStart']=state(page)
        page.wait_for_timeout(650)
        result['states']['offscreen']=state(page)
        assert result['states']['offscreen']['paused']
        assert result['states']['offscreen']['ribbonState']=='running'
        assert result['states']['offscreen']['ribbonTransform']!=result['states']['ribbonStart']['ribbonTransform']
        page.locator('.film-overlay').scroll_into_view_if_needed()
        page.wait_for_timeout(650)
        result['states']['returnedToView']=state(page)
        assert not result['states']['returnedToView']['paused']
        # Invoke the actual page-level handler without scrolling the playing film out of view.
        page.locator('.motion-toggle').evaluate('(button)=>button.click()')
        page.wait_for_timeout(200)
        result['states']['globalPause']=state(page)
        assert result['states']['globalPause']['bodyMotionPaused'] and result['states']['globalPause']['paused']
        page.locator('.motion-toggle').evaluate('(button)=>button.click()')
        page.wait_for_timeout(350)
        result['states']['globalResume']=state(page)
        assert not result['states']['globalResume']['bodyMotionPaused'] and not result['states']['globalResume']['paused']
        context.close();browser.close()
    result['passed']=not result['consoleErrors'] and not result['failedResponses']
    output=Path(__file__).with_name('motion-observations.json')
    output.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
    assert result['passed']

if __name__=='__main__':
    main()
