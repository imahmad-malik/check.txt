"""Verify the default preview when the viewer can load only the HTML document.

This simulates unavailable sibling files. It does not establish the actual
chat viewer's sanitization/CSP or claim access to that UI.
"""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
document = (ROOT / 'index.html').read_text()
URL = 'http://127.0.0.1:8199/index.html'
requested = []
errors = []
report = {'actual_chat_viewer': 'Not directly accessible; user screenshot showed missing stylesheet. Default entry no longer needs sibling resources.'}

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    context = browser.new_context(viewport={'width': 1440, 'height': 1000})

    def serve_document_only(route):
        requested.append(route.request.url)
        if route.request.url == URL:
            route.fulfill(status=200, content_type='text/html', body=document)
        else:
            route.fulfill(status=404, body='Sibling files deliberately unavailable')

    context.route('**/*', serve_document_only)
    page = context.new_page()
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto(URL, wait_until='networkidle')
    page.evaluate("document.querySelectorAll('img').forEach(x => x.loading = 'eager')")
    page.evaluate('Promise.all([...document.images].map(x => x.decode()))')
    page.evaluate('document.fonts.ready')
    assert page.locator('img').count() == 25
    assert page.evaluate('document.fonts.check("16px Instrument") && document.fonts.check("16px DM")')
    assert page.locator('.hero').evaluate('node => getComputedStyle(node).display') == 'grid'
    assert page.locator('body').evaluate('node => getComputedStyle(node).backgroundColor') == 'rgb(246, 242, 236)'
    assert page.locator('.header-explore svg').evaluate('node => node.getBoundingClientRect().width') < 24
    assert page.locator('html').get_attribute('class') == 'js-ready'
    page.screenshot(path=str(ROOT / 'tests/screenshots/preview-fixed-desktop.jpg'), type='jpeg', quality=90)

    page.locator('#gallery-search').fill('Silver')
    assert page.locator('.look-card:visible').count() == 1
    page.locator('#clear-filters').click()
    page.locator('.look-card[data-id="soft-layered"] .save-look').click()
    page.locator('#saved-button').click()
    assert page.locator('#saved-dialog img').count() == 1
    page.keyboard.press('Escape')
    assert page.locator('.look-card img').count() == 8
    page.locator('#film-play').scroll_into_view_if_needed()
    page.locator('#film-play').click()
    page.wait_for_function("document.getElementById('editorial-film').currentTime > 0.1")
    page.locator('#film-play').click()
    page.set_viewport_size({'width': 390, 'height': 844})
    page.evaluate('document.activeElement.blur(); window.scrollTo(0, 0)')
    assert page.evaluate('document.documentElement.scrollWidth') == 390
    assert page.locator('#site-nav').is_hidden()
    page.locator('#menu-toggle').click()
    assert page.locator('#site-nav').is_visible()
    page.keyboard.press('Escape')
    page.evaluate('document.activeElement.blur()')
    page.screenshot(path=str(ROOT / 'tests/screenshots/preview-fixed-mobile.jpg'), type='jpeg', quality=90)

    assert not errors
    assert requested == [URL], requested
    report.update({'status': 'passed', 'requests': requested, 'image_elements_loaded': 25,
                   'styling_fonts_svg_sizes': 'passed', 'search_saved_mobile_video': 'passed',
                   'external_asset_requests': 0, 'page_errors': errors})
    browser.close()

(ROOT / 'tests/preview-isolation-report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
