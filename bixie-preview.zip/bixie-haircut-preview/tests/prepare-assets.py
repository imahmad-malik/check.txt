"""Encode generated source PNGs as web assets, without cropping or retouching.

The original pictures are created by the image-generation tool. This script
performs format encoding, then builds an explicitly labelled still-image motion
study. It does not claim new photographs or real salon footage.
"""
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
IMAGES = ROOT / 'assets/images'
mapping = json.loads((ROOT / 'assets/asset-map.json').read_text())
missing = []
for destination, source in mapping.items():
    src = IMAGES / (source + '.png')
    out = IMAGES / (destination + '.webp')
    if not src.exists():
        missing.append(source)
        continue
    if out.exists() and out.stat().st_mtime >= src.stat().st_mtime:
        continue
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                    '-i', str(src), '-frames:v', '1', '-c:v', 'libwebp',
                    '-quality', '86', '-compression_level', '6', str(out)], check=True)
    print('Encoded', out.name)

film_source = IMAGES / 'motion-landscape.png'
film_out = ROOT / 'assets/editorial-motion.mp4'
if film_source.exists() and (not film_out.exists() or film_out.stat().st_mtime < film_source.stat().st_mtime):
    # Slow, reversible zoom of a dedicated image; no cut simulation or fake video.
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                    '-i', str(film_source), '-vf',
                    "scale=1800:-2,zoompan=z='1+0.05*sin(on/359*PI)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=360:s=1440x810:fps=30",
                    '-frames:v', '360', '-c:v', 'libx264', '-preset', 'medium', '-crf', '23',
                    '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-an', str(film_out)], check=True)
    print('Encoded editorial motion study', film_out.name)
if missing:
    print('Awaiting original sources:', ', '.join(missing))
    sys.exit(2)
print('All 26 distinct source slots encoded.')
