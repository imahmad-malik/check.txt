#!/usr/bin/env python3
"""Verify the compact fallback with every sibling resource unavailable."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
DOCUMENT = ROOT.parent / "preview-light.html"
URL = "http://127.0.0.1:8198/preview-light.html"


def main():
    document = DOCUMENT.read_text()
    requests, errors = [], []
    report = {"document": str(DOCUMENT), "bytes": DOCUMENT.stat().st_size,
              "actual_chat_viewer": "Not directly accessible; checks use local Chromium with a document-only route."}
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path="/usr/bin/chromium", headless=True, args=["--no-sandbox"])
        context = browser.new_context(viewport={"width": 1440, "height": 1000})

        def document_only(route):
            requests.append(route.request.url)
            if route.request.url == URL:
                route.fulfill(status=200, content_type="text/html", body=document)
            else:
                route.fulfill(status=404, body="No sibling files available")

        context.route("**/*", document_only)
        page = context.new_page()
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto(URL, wait_until="networkidle")
        page.evaluate("document.querySelectorAll('img').forEach(i => i.loading='eager')")
        page.evaluate("Promise.all([...document.images].map(i => i.decode()))")
        page.evaluate("Promise.all([...document.fonts].map(f => f.load()))")
        assets = page.evaluate("""() => ({
          images: [...document.images].map(i => ({loaded:i.complete && i.naturalWidth>0,
            naturalWidth:i.naturalWidth, naturalHeight:i.naturalHeight,
            width:Number(i.getAttribute('width')), height:Number(i.getAttribute('height'))})),
          uniqueSources:new Set([...document.images].map(i=>i.src).concat(document.querySelector('video').poster)).size,
          fonts:[...document.fonts].map(f=>({family:f.family,weight:f.weight,style:f.style,status:f.status})),
          heroLayout:getComputedStyle(document.querySelector('.hero')).display,
          background:getComputedStyle(document.body).backgroundColor,
          serif:getComputedStyle(document.querySelector('h1')).fontFamily,
          sans:getComputedStyle(document.body).fontFamily,
          svgWidth:document.querySelector('.header-explore svg').getBoundingClientRect().width
        })""")
        assert len(assets["images"]) == 25 and assets["uniqueSources"] == 26
        assert all(i["loaded"] and i["naturalWidth"] <= 480 and i["naturalWidth"] == i["width"]
                   and i["naturalHeight"] == i["height"] for i in assets["images"])
        assert len(assets["fonts"]) == 7 and all(f["status"] == "loaded" for f in assets["fonts"])
        assert assets["heroLayout"] == "grid" and assets["background"] == "rgb(246, 242, 236)"
        assert assets["svgWidth"] < 24
        expect(page.locator("html")).to_have_class("js-ready")
        page.screenshot(path=str(ROOT / "tests/screenshots/preview-light-desktop.jpg"), type="jpeg", quality=84)

        page.locator("#gallery-search").fill("Silver")
        expect(page.locator(".look-card:visible")).to_have_count(1)
        page.locator("#clear-filters").click()
        page.select_option("#texture-filter", "fine")
        expect(page.locator(".look-card:visible")).to_have_count(2)
        page.locator("#clear-filters").click()
        for look in ["soft-layered", "curly"]:
            page.locator(f'.look-card[data-id="{look}"] .save-look').click()
        expect(page.locator("#saved-count")).to_have_text("2")
        page.locator("#saved-button").click()
        expect(page.locator("#saved-dialog img")).to_have_count(2)
        page.locator("#compare-saved").click()
        expect(page.locator("#compare-dialog img")).to_have_count(2)
        page.keyboard.press("Escape")
        expect(page.locator(".look-card img")).to_have_count(8)
        expect(page.locator("img")).to_have_count(25)
        page.locator('.open-guide[data-guide="stylist"]').first.click()
        expect(page.locator("#guide-dialog")).to_be_visible()
        page.keyboard.press("Escape")

        page.locator("#film-play").scroll_into_view_if_needed()
        page.locator("#film-play").click()
        page.wait_for_function("document.querySelector('#editorial-film').currentTime>0.3")
        video = page.locator("#editorial-film").evaluate("v => ({width:v.videoWidth,height:v.videoHeight,duration:v.duration,currentTime:v.currentTime,paused:v.paused,error:v.error?.code||null})")
        assert video["width"] == 480 and video["height"] == 270 and video["duration"] == 12
        assert not video["paused"] and not video["error"]
        page.locator("#film-play").click()
        assert page.locator("#editorial-film").evaluate("v=>v.paused")
        page.locator("#moving-edit").scroll_into_view_if_needed()
        page.wait_for_function("getComputedStyle(document.querySelector('.ribbon-track')).animationPlayState==='running'")
        ribbon_before = page.locator(".ribbon-track").evaluate("r=>getComputedStyle(r).transform")
        page.wait_for_timeout(180)
        ribbon_after = page.locator(".ribbon-track").evaluate("r=>getComputedStyle(r).transform")
        assert ribbon_before != ribbon_after
        page.locator(".motion-toggle").evaluate("button=>button.click()")
        assert page.locator("body").evaluate("b=>b.classList.contains('motion-paused')")

        page.set_viewport_size({"width": 390, "height": 844})
        page.evaluate("document.activeElement.blur();window.scrollTo(0,0)")
        assert page.evaluate("document.documentElement.scrollWidth") == 390
        expect(page.locator("#site-nav")).not_to_be_visible()
        page.locator("#menu-toggle").click()
        expect(page.locator("#site-nav")).to_be_visible()
        page.keyboard.press("Escape")
        page.evaluate("document.activeElement.blur()")
        page.screenshot(path=str(ROOT / "tests/screenshots/preview-light-mobile.jpg"), type="jpeg", quality=84)
        assert not errors and requests == [URL]
        report.update({"status": "passed", "assets": assets, "video": video,
                       "requests": requests, "external_requests": 0, "page_errors": errors,
                       "checks": ["All 25 images and 26 distinct slots; correct image dimensions",
                                  "Seven embedded font faces; styled desktop layout; SVG dimensions",
                                  "Search, texture filter, saved looks, comparison and image restoration",
                                  "Guide modal; actual MP4 playback/pause; moving photos and pause control",
                                  "390px mobile layout and navigation"]})
        browser.close()
    (ROOT / "tests/compact-qa-report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ["status", "bytes", "external_requests", "page_errors", "video"]}))


if __name__ == "__main__":
    main()
