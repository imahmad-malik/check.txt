#!/usr/bin/env python3
"""Run real-browser interaction checks against the included HTML homepage.

Requires Python Playwright and Chromium (or PLAYWRIGHT_CHROMIUM_EXECUTABLE).
Run: python tests/integration.py
Missing image assets are reported separately and do not masquerade as readiness.
"""

import functools
import http.server
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading

from playwright.sync_api import Error as PlaywrightError, sync_playwright, expect


ROOT = Path(__file__).resolve().parents[1]
REPORT_PATH = ROOT / "tests" / "interaction-report.json"


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


def run():
    server = http.server.ThreadingHTTPServer(
        ("127.0.0.1", 0), functools.partial(QuietHandler, directory=str(ROOT))
    )
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_port}/index.html"
    checks = []
    errors = []
    report = {"checks": checks, "page_errors": errors, "asset_readiness": "not established by interaction checks"}

    with sync_playwright() as playwright:
        executable = os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE") or shutil.which("chromium")
        browser = playwright.chromium.launch(
            executable_path=executable, headless=True, args=["--no-sandbox"]
        )

        def attach(page):
            page.on("pageerror", lambda error: errors.append(str(error)))

        def all_images_unique(page):
            summary = page.evaluate("""() => {
                const images = [...document.querySelectorAll('img')];
                const sources = images.map(image => image.getAttribute('src'));
                return {total: images.length, unique: new Set(sources).size};
            }""")
            assert summary["total"] == summary["unique"], summary
            return summary["total"]

        def restore_check(page, total):
            expect(page.locator(".look-card img")).to_have_count(8)
            expect(page.locator("img")).to_have_count(total)
            assert page.evaluate("""() => window.__originalGalleryImages.every(image =>
                image.isConnected && image.closest('.look-card'))""")
            all_images_unique(page)

        context = browser.new_context(viewport={"width": 1440, "height": 1000})
        page = context.new_page()
        attach(page)
        page.goto(base, wait_until="domcontentloaded")
        expect(page.locator("html")).to_have_class("js-ready")
        assert not page.locator("body").evaluate("node => node.classList.contains('motion-paused')")
        page.locator(".motion-toggle").click()
        assert page.locator("body").evaluate("node => node.classList.contains('motion-paused')")
        total = all_images_unique(page)
        page.evaluate("window.__originalGalleryImages = [...document.querySelectorAll('.look-card img')]")
        expect(page.locator(".look-card:not([hidden])")).to_have_count(8)
        page.select_option("#texture-filter", "fine")
        expect(page.locator(".look-card:not([hidden])")).to_have_count(2)
        page.select_option("#length-filter", "short")
        expect(page.locator(".look-card:not([hidden])")).to_have_count(1)
        page.select_option("#fringe-filter", "curtain")
        expect(page.locator(".look-card:not([hidden])")).to_have_count(0)
        expect(page.locator("#gallery-empty")).to_be_visible()
        page.locator("#gallery-empty button").click()
        expect(page.locator(".look-card:not([hidden])")).to_have_count(8)
        page.fill("#gallery-search", "silver")
        expect(page.locator(".look-card:not([hidden])")).to_have_count(1)
        expect(page.locator(".look-card:not([hidden])")).to_have_attribute("data-id", "silver")
        page.locator("#clear-filters").click()
        page.select_option("#colour-filter", "blonde")
        expect(page.locator(".look-card:not([hidden])")).to_have_count(1)
        expect(page.locator(".look-card:not([hidden])")).to_have_attribute("data-id", "feathered")
        page.select_option("#colour-filter", "copper")
        expect(page.locator(".look-card:not([hidden])")).to_have_count(0)
        expect(page.locator("#gallery-empty")).to_be_visible()
        page.locator("#clear-filters").click()
        page.select_option("#sort-filter", "title")
        titles = page.locator(".look-card").evaluate_all("nodes => nodes.map(node => node.dataset.title)")
        assert titles == sorted(titles), titles
        page.select_option("#sort-filter", "latest")
        expect(page.locator(".look-card").first).to_have_attribute("data-id", "silver")
        expect(page.locator(".look-card").last).to_have_attribute("data-id", "soft-layered")
        page.select_option("#sort-filter", "curated")
        expect(page.locator(".look-card").first).to_have_attribute("data-id", "soft-layered")
        checks.append("Exact filters, zero-result reset, search, A–Z and latest sorting")

        for look in ["soft-layered", "curly", "long", "feathered"]:
            page.locator(f".look-card[data-id='{look}'] .save-look").click()
        expect(page.locator("#saved-count")).to_have_text("4")
        assert len(json.loads(page.evaluate("localStorage.getItem('bixie-preview:saved:v1')"))) == 4
        page.locator("#saved-button").click()
        expect(page.locator("#saved-dialog")).to_be_visible()
        expect(page.locator("#saved-items img")).to_have_count(4)
        assert all_images_unique(page) == total
        page.locator(".compare-choice[data-look='feathered']").click()
        expect(page.locator(".compare-choice[data-look='feathered']")).not_to_be_checked()
        expect(page.locator("#saved-feedback")).to_contain_text("up to three")
        page.locator(".compare-choice[data-look='long']").uncheck()
        page.locator(".compare-choice[data-look='feathered']").check()
        page.locator("#compare-saved").click()
        expect(page.locator("#saved-dialog")).not_to_be_visible()
        expect(page.locator("#compare-dialog")).to_be_visible()
        expect(page.locator("#compare-items img")).to_have_count(3)
        assert all_images_unique(page) == total
        expect(page.locator("#compare-items")).to_contain_text("one-view AI")
        page.keyboard.press("Escape")
        restore_check(page, total)
        page.locator(".look-card[data-id='curly'] .look-caption .open-look").click()
        expect(page.locator("#look-dialog")).to_be_visible()
        expect(page.locator("#look-detail img")).to_have_count(1)
        expect(page.locator("#look-detail h4, #look-detail h5, #look-detail h6")).to_have_count(0)
        assert all_images_unique(page) == total
        page.locator("#look-dialog .close-dialog").click()
        restore_check(page, total)
        page.locator("#saved-button").click()
        page.locator(".remove-saved[data-look='long']").click()
        expect(page.locator("#saved-count")).to_have_text("3")
        expect(page.locator("#saved-items img")).to_have_count(3)
        assert all_images_unique(page) == total
        page.locator("#print-saved").click()
        expect(page.locator("#print-dialog")).to_be_visible()
        expect(page.locator("#print-items img")).to_have_count(3)
        expect(page.locator(".print-look-reference")).to_have_count(3)
        references = page.locator(".print-look-reference a").evaluate_all("nodes => nodes.map(node => node.href)")
        assert all(reference.startswith(base + "#look=") for reference in references), references
        expect(page.locator("#print-items")).to_contain_text("Look ID: soft-layered")
        expect(page.locator("#print-items")).to_contain_text("Original AI hairstyle concepts")
        page.evaluate("() => { window.__printCalls = 0; window.print = () => { window.__printCalls++; }; }")
        page.locator("#print-now").click()
        assert page.evaluate("window.__printCalls") == 1, {"calls": page.evaluate("window.__printCalls"), "page_errors": errors, "open_dialog": page.locator("dialog[open]").get_attribute("id")}
        page.emulate_media(media="print")
        pdf_path = Path(tempfile.gettempdir()) / "bixie-preview-salon-sheet-test.pdf"
        page.pdf(path=str(pdf_path), print_background=True, prefer_css_page_size=True)
        assert pdf_path.stat().st_size > 1000
        page.emulate_media(media="screen")
        page.keyboard.press("Escape")
        restore_check(page, total)
        checks.append("Shortlist persistence, max-three comparison, image-node uniqueness/restoration, accessible modal switching, print invocation and PDF rendering")

        page.locator("#finder-form label:has(input[name='texture'][value='fine'])").click()
        page.locator("#finder-form label:has(input[name='length'][value='short'])").click()
        page.locator("#finder-form label:has(input[name='fringe'][value='side-swept'])").click()
        page.locator("#finder-form button[type='submit']").click()
        expect(page.locator(".look-card:not([hidden])")).to_have_count(1)
        expect(page.locator("#finder-status")).to_contain_text("1 preview look matches")
        page.locator(".texture-card[data-texture='curly']").click()
        expect(page.locator(".look-card:not([hidden])")).to_have_count(1)
        expect(page.locator(".look-card:not([hidden])")).to_have_attribute("data-id", "curly")
        for guide in ["what-is-bixie", "privacy", "image-policy", "contact"]:
            page.locator(f".open-guide[data-guide='{guide}']").first.click()
            expect(page.locator("#guide-dialog")).to_be_visible()
            expect(page.locator("#guide-content h2")).to_have_count(1)
            if guide != "what-is-bixie":
                assert "Individual haircut advice" not in page.locator("#guide-content").inner_text()
            page.keyboard.press("Escape")
        page.locator("#coverage-toggle").click()
        expect(page.locator("#coverage-dialog")).to_be_visible()
        page.keyboard.press("Escape")
        page.reload(wait_until="domcontentloaded")
        expect(page.locator("#saved-count")).to_have_text("3")
        page.goto(base + "#look=curly", wait_until="domcontentloaded")
        expect(page.locator("#look-dialog")).to_be_visible()
        expect(page.locator("#look-detail")).to_contain_text("Curly bixie")
        assert all_images_unique(page) == total
        page.keyboard.press("Escape")
        checks.append("Finder and collection filters, editorial/privacy/contact dialogs, coverage dialog and local printed-look deep link")

        mobile = browser.new_context(viewport={"width": 390, "height": 844}, reduced_motion="reduce")
        mobile_page = mobile.new_page()
        attach(mobile_page)
        mobile_page.goto(base, wait_until="domcontentloaded")
        assert mobile_page.locator("body").evaluate("node => node.classList.contains('motion-paused')")
        expect(mobile_page.locator(".motion-toggle")).to_have_attribute("aria-pressed", "true")
        expect(mobile_page.locator("#site-nav")).not_to_be_visible()
        mobile_page.locator("#menu-toggle").click()
        expect(mobile_page.locator("#menu-toggle")).to_have_attribute("aria-expanded", "true")
        expect(mobile_page.locator("#site-nav")).to_be_visible()
        mobile_page.locator("#menu-toggle").focus()
        mobile_page.keyboard.press("Shift+Tab")
        expect(mobile_page.locator("#site-nav a").last).to_be_focused()
        mobile_page.keyboard.press("Tab")
        expect(mobile_page.locator("#menu-toggle")).to_be_focused()
        mobile_page.keyboard.press("Escape")
        expect(mobile_page.locator("#menu-toggle")).to_have_attribute("aria-expanded", "false")
        expect(mobile_page.locator("#menu-toggle")).to_be_focused()
        assert mobile_page.locator("#editorial-film").evaluate("video => video.paused")
        mobile.close()
        checks.append("Reduced-motion default, paused video, mobile navigation keyboard wrap and Escape focus restoration")

        no_storage = browser.new_context(reduced_motion="reduce")
        no_storage.add_init_script("Object.defineProperty(window, 'localStorage', { get() { throw new DOMException('Storage unavailable', 'SecurityError'); } });")
        storage_page = no_storage.new_page()
        attach(storage_page)
        storage_page.goto(base, wait_until="domcontentloaded")
        storage_page.locator(".look-card[data-id='curly'] .save-look").click()
        expect(storage_page.locator("#saved-count")).to_have_text("1")
        storage_page.locator("#saved-button").click()
        expect(storage_page.locator("#saved-items")).to_contain_text("storage is unavailable")
        storage_page.reload(wait_until="domcontentloaded")
        expect(storage_page.locator("#saved-count")).to_have_text("0")
        no_storage.close()
        checks.append("Graceful session-only shortlist when browser storage is denied")

        failed_media = browser.new_context(reduced_motion="reduce")
        failed_media.route("**/editorial-motion.mp4", lambda route: route.fulfill(status=404, body="Missing media for error-path test"))
        media_page = failed_media.new_page()
        attach(media_page)
        media_page.goto(base, wait_until="domcontentloaded")
        media_page.evaluate("""url => { const video = document.getElementById('editorial-film'); video.querySelector('source').src = url; video.load(); }""", base + "/assets/editorial-motion.mp4")
        media_page.locator("#film-play").click()
        expect(media_page.locator("#film-status")).to_be_visible()
        expect(media_page.locator("#film-status")).to_contain_text("still images remain available")
        expect(media_page.locator("#film-play")).to_have_attribute("aria-pressed", "false")
        failed_media.close()
        checks.append("Real 404 media load provides visible and announced feedback without a page error")

        film_path = ROOT / "assets" / "editorial-motion.mp4"
        if film_path.is_file() and film_path.stat().st_size:
            playback = browser.new_context(reduced_motion="reduce")
            playback_page = playback.new_page()
            attach(playback_page)
            playback_page.goto(base, wait_until="domcontentloaded")
            playback_page.locator("#film-play").click()
            playback_page.wait_for_function("document.getElementById('editorial-film').currentTime > 0", timeout=10000)
            expect(playback_page.locator("#film-play")).to_have_attribute("aria-pressed", "true")
            playback_page.locator("#film-play").click()
            expect(playback_page.locator("#film-play")).to_have_attribute("aria-pressed", "false")
            playback.close()
            checks.append("Actual included MP4 playback and pause")
            report["film_playback"] = "passed"
        else:
            report["film_playback"] = "skipped: asset not present yet"

        local_file = browser.new_context(reduced_motion="reduce")
        file_page = local_file.new_page()
        attach(file_page)
        file_url = (ROOT / "index.html").as_uri()
        try:
            file_page.goto(file_url, wait_until="domcontentloaded")
        except PlaywrightError as error:
            if "ERR_BLOCKED_BY_ADMINISTRATOR" not in str(error):
                raise
            report["direct_file_open"] = "not verified: managed Chromium blocks file:// URLs (ERR_BLOCKED_BY_ADMINISTRATOR); local HTTP preview is verified"
        else:
            expect(file_page.locator("html")).to_have_class("js-ready")
            expect(file_page.locator(".look-card")).to_have_count(8)
            file_page.evaluate("() => document.fonts.ready")
            assert file_page.evaluate("document.fonts.check('16px Instrument') && document.fonts.check('16px DM')")
            file_page.locator(".look-card[data-id='curly'] .save-look").click()
            file_page.locator("#saved-button").click()
            expect(file_page.locator("#saved-items img")).to_have_count(1)
            file_page.locator("#print-saved").click()
            expect(file_page.locator(".preview-look-url")).to_have_attribute("href", file_url + "#look=curly")
            assert all_images_unique(file_page) == total
            report["direct_file_open"] = "passed"
            checks.append("Direct local index.html opening, bundled fonts, saved tools and real file URL salon reference")
        finally:
            local_file.close()

        report["homepage_images"] = total
        report["image_node_uniqueness"] = "passed"
        report["sample_print_pdf"] = str(pdf_path)
        assert not errors, errors
        report["status"] = "passed"
        REPORT_PATH.write_text(json.dumps(report, indent=2) + "\n")
        browser.close()
    server.shutdown()
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    run()
