"""Package the HTML preview and its real assets; create a single-file viewing copy."""
from pathlib import Path
import base64
import hashlib
import json
import mimetypes
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'releases'
OUT.mkdir(exist_ok=True)
compact_content = None
for candidate in [ROOT.parent / 'preview-light.html', ROOT / 'index.html']:
    if candidate.is_file() and candidate.stat().st_size < 1000000:
        candidate_content = candidate.read_text()
        if 'data:image/webp;base64,' in candidate_content and '<style>' in candidate_content:
            compact_content = candidate_content
            break

def data_uri(path):
    mime = mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
    return 'data:' + mime + ';base64,' + base64.b64encode(path.read_bytes()).decode('ascii')

html = (ROOT / 'source.html').read_text()
css = (ROOT / 'assets/style.css').read_text()
js = (ROOT / 'assets/app.js').read_text()

def inline_css_asset(match):
    path = ROOT / 'assets' / match.group(1)
    if not path.is_file():
        raise FileNotFoundError(path)
    return 'url("' + data_uri(path) + '")'

css = re.sub(r'url\([\'"]?([^\)\'\"]+)[\'"]?\)', inline_css_asset, css)
html = re.sub(r'<link\b[^>]*rel="preload"[^>]*>', '', html)
html = re.sub(r'<link\b[^>]*href="assets/style.css"[^>]*>', '<style>\n' + css + '\n</style>', html)
html = re.sub(r'<script\b[^>]*src="assets/app.js"[^>]*>\s*</script>', lambda _: '<script>\n' + js + '\n</script>', html)

def inline_html_asset(match):
    path = ROOT / match.group(2)
    if not path.is_file():
        raise FileNotFoundError(path)
    return match.group(1) + '="' + data_uri(path) + '"'

html = re.sub(r'(src|poster|href)="(assets/[^\"]+)"', inline_html_asset, html)
(ROOT / 'index.html').write_text(html)
(OUT / 'Bixie-Haircut-Preview.html').write_text(html)
(OUT / 'Bixie-Haircut-Preview-Fixed.html').write_text(html)
if compact_content:
    (OUT / 'Bixie-Haircut-Preview-Light.html').write_text(compact_content)

manifest = json.loads((ROOT / 'assets/image-manifest.json').read_text())
display_files = {ROOT / r['display_file'] for r in manifest['records']}
source_files = {ROOT / r['source_file'] for r in manifest['records']}
assert len(display_files) == len(source_files) == 26
assert all(p.is_file() for p in display_files)
originals_available = all(p.is_file() for p in source_files)
if originals_available:
    assert len({hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}) == 26

files = {ROOT / 'source.html', ROOT / 'index.html', ROOT / 'README.md', ROOT / 'VALIDATION-REPORT.md'}
files |= display_files
files |= {ROOT / ('assets/' + n) for n in ['style.css', 'app.js', 'favicon.svg', 'editorial-motion.mp4', 'asset-map.json', 'image-manifest.json', 'generation-prompts.json']}
files |= set((ROOT / 'docs').glob('*.md'))
files |= set((ROOT / 'research').glob('*'))
files |= set((ROOT / 'tests').glob('*.py'))
files |= set((ROOT / 'tests').glob('*.json'))
font_names = re.findall(r'url\([\'"]?(fonts/[^\)\'\"]+)', (ROOT / 'assets/style.css').read_text())
files |= {ROOT / 'assets' / n for n in font_names}
files |= set((ROOT / 'assets/fonts').glob('*LICENSE.txt'))

def archive(name, members, prefix, compact_entry=False):
    with zipfile.ZipFile(OUT / name, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(members):
            if p.is_file():
                relative = str(p.relative_to(ROOT))
                if compact_entry and compact_content and relative == 'index.html':
                    z.writestr(prefix + '/index.html', compact_content)
                else:
                    z.write(p, prefix + '/' + relative)

archive('Bixie-Haircut-HTML-Package.zip', files, 'bixie-haircut-preview', compact_entry=True)
if originals_available:
    archive('Bixie-Haircut-Original-Images.zip', source_files | {ROOT / 'assets/image-manifest.json', ROOT / 'assets/generation-prompts.json', ROOT / 'assets/asset-map.json'}, 'bixie-haircut-source-images')
else:
    print('Original source PNGs absent: skipped originals archive; HTML package still built.')

evidence_names = ['desktop-hero.jpg', 'desktop-full.jpg', 'phone-hero.jpg', 'phone-full.jpg', 'desktop-gallery.png', 'desktop-all-angles.png', 'desktop-compare.png', 'phone-compare.png', 'desktop-look.png', 'phone-menu.png', 'print-consultation.pdf', 'print-consultation.png', 'preview-fixed-desktop.jpg', 'preview-fixed-mobile.jpg', 'preview-light-desktop.jpg', 'preview-light-mobile.jpg']
evidence = {ROOT / 'tests/screenshots' / n for n in evidence_names if (ROOT / 'tests/screenshots' / n).is_file()}
if evidence:
    archive('Bixie-Haircut-Browser-Evidence.zip', evidence, 'bixie-haircut-evidence')
delivery = {}
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.name != 'delivery-manifest.json':
        delivery[p.name] = {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
(OUT / 'delivery-manifest.json').write_text(json.dumps(delivery, indent=2) + '\n')
for name, d in delivery.items():
    print(name, f"{d['bytes']/1024/1024:.1f} MiB")
